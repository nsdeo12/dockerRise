app.controller('DocumentsController', function($scope ,$uibModal,$rootScope,$http,$location,$cookies,$window,$cookieStore) {
                                const apiBaseURL = $rootScope.apiBaseURL;
                                  $scope.LCRequestId = $rootScope.LCID;
                                  $scope.node = $rootScope.thisNode;
                                  $scope.username = $cookieStore.get('employee');
                                  $scope.logout = function(){
                                  $cookieStore.remove('customer');
                                  $location.path("/customer");
                                        };
                         const getObj = apiBaseURL + "employee-lc-orders/"+$scope.LCRequestId;
                         $scope.getbills = () => $http.get(getObj).then(function(response) {
                         $scope.bills = response.data[0].lcorder.bills;
                         $scope.getData = response.data[0];
                         console.log("response.data[0] in bill",$scope.bills);
                         console.log("response.data[0] in lcorders",$scope.getData);
                          })
                        $scope.getbills();
                  $scope.getUploads = () => $http.get("http://"+window.__env.apiUrl+":10009/getfilenames/"+$rootScope.LCID).then(function(response) {
                  console.log("upload response",response);
                  $scope.choices= response.data;
                  console.log("response.data in bill",$scope.choices);
     })

         $scope.getUploads();
         $scope.Downlod = (choice) => {
                                                 $http.get("http://"+window.__env.apiUrl+":10009/download/"+$rootScope.LCID+"/"+choice).then(function(response) {
                                                 console.log("http://"+window.__env.apiUrl+":10009/download/"+$rootScope.LCID+"/"+choice);
                                                 $window.location.href = "http://"+window.__env.apiUrl+":10009/download/"+$rootScope.LCID+"/"+choice;

                                          })
                                          }


                                          $scope.verify = function() {
                                             $http.get(getObj).then(function(response){
                                               var finalData = response.data;
                                            console.log("RESPONSE DATA ", finalData[0]);
                                                const VerifyStatus = {
                                                lcId : $scope.LCRequestId,
                                                 lcReqId : finalData[0].lcorder.lcReqId,
                                                 applicantCustomer : finalData[0].lcorder.applicantCustomer,
                                                 applicantAddress : finalData[0].lcorder.applicantAddress,
                                                // shipmentPeriod : finalData[0].lcorder.shipmentPeriod,
                                                 lcExpiryDate : finalData[0].lcorder.lcExpiryDate,
                                                 modeOfShipment :  finalData[0].lcorder.modeOfShipment,
                                                 beneficiaryId : finalData[0].lcorder.beneficiaryId,
                                                 beneficiaryAddress : finalData[0].lcorder.beneficiaryAddress,
                                                 lcType : finalData[0].lcorder.lcType,
                                                 lcCurrency : finalData[0].lcorder.lcCurrency,
                                                 lcAmount :  finalData[0].lcorder.lcAmount,
                                                 lcAmountTemp : finalData[0].lcorder.lcAmount,

                                                lcIssueDate : finalData[0].lcorder.lcIssueDate,
                                                 lcExpiryPlace : finalData[0].lcorder.lcExpiryPlace,
                                                 latestShipmentDate : finalData[0].lcorder.latestShipmentDate,
                                                 liabilityReversalDate : finalData[0].lcorder.liabilityReversalDate,
                                                 advisingBankID : finalData[0].lcorder.advisingBankID,
                                                 applicantBank : finalData[0].lcorder.applicantBank,
                                                 applicantBankAddress : finalData[0].lcorder.applicantBankAddress,
                                                 advisingBankAddress : finalData[0].lcorder.advisingBankAddress,
                                                 formofDocumentaryCredit : finalData[0].lcorder.formofDocumentaryCredit,
                                                 documentaryCreditNumber : finalData[0].lcorder.documentaryCreditNumber,
                                                 availableWithBy : finalData[0].lcorder.availableWithBy,
                                                 forTransportationTo : finalData[0].lcorder.forTransportationTo,
                                                 descriptionOfGoodsAndOrServices : finalData[0].lcorder.descriptionOfGoodsAndOrServices,
                                                 additionalConditions : finalData[0].lcorder.additionalConditions,
                                                 periodForPresentation : finalData[0].lcorder.periodForPresentation,
                                                 advisingThroughBank : finalData[0].lcorder.advisingThroughBank,
                                                 transshipment : finalData[0].lcorder.transshipment,
                                                 portofLoading : finalData[0].lcorder.portofLoading,
                                                 maximumCreditAmount : finalData[0].lcorder.maximumCreditAmount,
                                                 draftsAt : finalData[0].lcorder.draftsAt,
                                                 partialShipments : finalData[0].lcorder.partialShipments,
                                                 senderToReceiverInformation : finalData[0].lcorder.senderToReceiverInformation,
                                                 charges : finalData[0].lcorder.charges,
                                                 confirmationInstructions : finalData[0].lcorder.confirmationInstructions,
                                                 sequenceOfTotal : finalData[0].lcorder.sequenceOfTotal,
                                                 documentsRequired : finalData[0].lcorder.documentsRequired,
                                                ibanNumber : finalData[0].lcorder.ibanNumber,
                                                 incoTerms : finalData[0].lcorder.incoTerms,
                                                draftsAtSight:finalData[0].lcorder.draftsAtSight,
                                                draftsAtUsance:finalData[0].lcorder.draftsAtUsance,
                                                shipmentPeriodSight:finalData[0].lcorder.shipmentPeriodSight,
                                                shipmentPeriodUsance:finalData[0].lcorder.shipmentPeriodUsance,
                                                percentageSight:finalData[0].lcorder.percentageSight,
                                                percentageUsance :finalData[0].lcorder.percentageUsance,
                                                lcAmountSight:finalData[0].lcorder.lcAmountSight,
                                                lcAmountUsance:finalData[0].lcorder.lcAmountUsance

                                              };
                                              console.log("verify object Json",VerifyStatus);
                                               const createVerifyStatusEndpoint =
                                                       apiBaseURL +
                                                       "lc-docs-verify";
                                               $http.post(createVerifyStatusEndpoint, angular.toJson(VerifyStatus)).then(
                                                  function(result){
                                                   // success callback
                                                   console.log("INSIDE SUCCESS FUNCTION");
                                                   alert("Documents Verified");
                                                   $location.path("/employeeHome");
                                                    }, 
                                                   function(result){
                                                   // failure callback
                                                      console.log("upload Status Failure");
                                                   });
                                           });
                                      }

               //1. Used to list all selected files
                  $scope.files = [];


                  //3. listen for the file selected event which is raised from directive
                  $scope.$on("seletedFile", function (event, args) {
                      $scope.$apply(function () {
                          //add the file object to the scope's files collection
                          $scope.files.push(args.file);
                      });
                  });

                  //4. Post data and selected files.
                  $scope.save = function () {
                      $http({
                          method: 'POST',
                          url: "http://"+window.__env.apiUrl+":10009/upload/"+$rootScope.LCID,
                          headers: { 'Content-Type': undefined },
                          transformRequest: function (data) {
                                                             var formData = new FormData();
//                                                             formData.append("model", angular.toJson(data.model));
                                                             for (var i = 0; i < data.files.length; i++) {
                                                              formData.append("file" + i, data.files[i]);
                                                             }
                              return formData;
                          },
                          data: { files: $scope.files }
                        }).
                        success(function () {
                              $http.get(getObj).then(function(response){
                                                    var finalData = response.data;
                                                    console.log("RESPONSE DATA ", finalData[0]);
                                                           const uploadStatus = {
                                                            lcId : $scope.LCRequestId,
                                                             lcReqId : finalData[0].lcorder.lcReqId,
                                                             applicantCustomer : finalData[0].lcorder.applicantCustomer,
                                                             applicantAddress : finalData[0].lcorder.applicantAddress,
                                                            // shipmentPeriod : finalData[0].lcorder.shipmentPeriod,
                                                             lcExpiryDate : finalData[0].lcorder.lcExpiryDate,
                                                             modeOfShipment :  finalData[0].lcorder.modeOfShipment,
                                                             beneficiaryId : finalData[0].lcorder.beneficiaryId,
                                                             beneficiaryAddress : finalData[0].lcorder.beneficiaryAddress,
                                                             lcType : finalData[0].lcorder.lcType,
                                                             lcCurrency : finalData[0].lcorder.lcCurrency,
                                                             lcAmount :  finalData[0].lcorder.lcAmount,
                                                             lcAmountTemp : finalData[0].lcorder.lcAmount,
                                                            lcIssueDate : finalData[0].lcorder.lcIssueDate,
                                                             lcExpiryPlace : finalData[0].lcorder.lcExpiryPlace,
                                                             latestShipmentDate : finalData[0].lcorder.latestShipmentDate,
                                                             liabilityReversalDate : finalData[0].lcorder.liabilityReversalDate,
                                                             advisingBankID : finalData[0].lcorder.advisingBankID,
                                                             applicantBank : finalData[0].lcorder.applicantBank,
                                                             applicantBankAddress : finalData[0].lcorder.applicantBankAddress,
                                                             advisingBankAddress : finalData[0].lcorder.advisingBankAddress,
                                                             formofDocumentaryCredit : finalData[0].lcorder.formofDocumentaryCredit,
                                                             documentaryCreditNumber : finalData[0].lcorder.documentaryCreditNumber,
                                                             availableWithBy : finalData[0].lcorder.availableWithBy,
                                                             forTransportationTo : finalData[0].lcorder.forTransportationTo,
                                                             descriptionOfGoodsAndOrServices : finalData[0].lcorder.descriptionOfGoodsAndOrServices,
                                                             additionalConditions : finalData[0].lcorder.additionalConditions,
                                                             periodForPresentation : finalData[0].lcorder.periodForPresentation,
                                                             advisingThroughBank : finalData[0].lcorder.advisingThroughBank,
                                                             transshipment : finalData[0].lcorder.transshipment,
                                                             portofLoading : finalData[0].lcorder.portofLoading,
                                                             maximumCreditAmount : finalData[0].lcorder.maximumCreditAmount,
                                                             draftsAt : finalData[0].lcorder.draftsAt,
                                                             partialShipments : finalData[0].lcorder.partialShipments,
                                                             senderToReceiverInformation : finalData[0].lcorder.senderToReceiverInformation,
                                                             charges : finalData[0].lcorder.charges,
                                                             confirmationInstructions : finalData[0].lcorder.confirmationInstructions,
                                                             sequenceOfTotal : finalData[0].lcorder.sequenceOfTotal,
                                                             documentsRequired : finalData[0].lcorder.documentsRequired,
                                                            ibanNumber : finalData[0].lcorder.ibanNumber,
                                                             incoTerms : finalData[0].lcorder.incoTerms,
                                                             draftsAtSight:finalData[0].lcorder.draftsAtSight,
                                                            draftsAtUsance:finalData[0].lcorder.draftsAtUsance,
                                                            shipmentPeriodSight:finalData[0].lcorder.shipmentPeriodSight,
                                                            shipmentPeriodUsance:finalData[0].lcorder.shipmentPeriodUsance,
                                                            percentageSight:finalData[0].lcorder.percentageSight,
                                                            percentageUsance :finalData[0].lcorder.percentageUsance,
                                                            lcAmountSight:finalData[0].lcorder.lcAmountSight,
                                                            lcAmountUsance:finalData[0].lcorder.lcAmountUsance

                                                         };
                                                         console.log("uploadStatus object Json",uploadStatus);
                                                          const createUploadStatusEndpoint =
                                                                  apiBaseURL +
                                                                  "lc-upload";
                                                          $http.post(createUploadStatusEndpoint, angular.toJson(uploadStatus)).then(
                                                             function(result){
                                                              // success callback
                                                               alert("Document Uploaded successfully");
                                                              console.log("INSIDE SUCCESS FUNCTION");
                                                              $location.path("/employeeHome");

                                                              }, 
                                                              function(result){
                                                              // failure callback
                                                                 console.log("upload Status Failure");
                                                              });
                                                      });


                                  }).
                        error(function () {
                          alert("failed!");
                          $location.path("/Documents");
                       });
                        }
                        $scope.showTheForm = true;
                        $scope.showTheForm1 = false;
//                                       $scope.addNewChoice = function() {
//                                       $scope.showTheForm = true;
//                                       console.log($scope.choices.length);
//                                       const newItemNo = $scope.choices.length+1;
//                                       $scope.choices.push({'sno': newItemNo});
//                            };

           $scope.billInput = function(sno) {
            $http.get(apiBaseURL + "lcRequestID").then(function(response){
                 const billID = response.data.lcRequestID;
                 $scope.billform.billNumb = "BILL-"+billID;
                 console.log("lcRequestID in customer home page===>",response.data.lcRequestID);
             });
                 $scope.billSNO=sno;
                 $scope.showTheForm1 = true;
                 $scope.billcurrency = ['USD'];
                 $scope.amountChange = () =>  {
                             console.log("LC AMOUNT",$scope.billform.billamount);
                                     var value = $scope.billform.billamount;
                                     
                                     var Amtval = value.split(/^([-+]?[0-9]*\.?[0-9]+)([abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ])$/);
                                     console.log("AMT VAL  ",Amtval);

                                     if(Amtval[2].toLowerCase()=='m'|| Amtval[2].toLowerCase()=='h'|| Amtval[2].toLowerCase()=='t'){

                                     if(Amtval[2].toLowerCase()== "m"){
                                     $scope.billform.billamount = Amtval[1]*1000000;
                                     }
                                     else if(Amtval[2].toLowerCase()== "h")
                                     {
                                     $scope.billform.billamount = Amtval[1]*100;
                                     }
                                     else if(Amtval[2].toLowerCase()== "t")
                                     {
                                     $scope.billform.billamount = Amtval[1]*1000;
                                     }
                                     else {
                                     $scope.billform.billamount = $scope.billform.billamount;
                                     }
                                     }
                                     else{
                                     console.log("inside check else");
                                     $scope.billform.billamount = "";

                                     }
                                   }

               $scope.create = () => {
                           $http.get(getObj).then(function(response){
                            var finalData = response.data;
                            console.log("RESPONSE DATA ", finalData[0]);
                            console.log("RESPONSE DATA final", finalData[0].lcorder);
                                   const bill = {
                                    lcId : $scope.LCRequestId,
                                    lcReqId : finalData[0].lcorder.lcReqId,
                                    applicantCustomer : finalData[0].lcorder.applicantCustomer,
                                    applicantAddress : finalData[0].lcorder.applicantAddress,
                                    //shipmentPeriod : finalData[0].lcorder.shipmentPeriod,
                                    lcExpiryDate : finalData[0].lcorder.lcExpiryDate,
                                    modeOfShipment :  finalData[0].lcorder.modeOfShipment,
                                    beneficiaryId : finalData[0].lcorder.beneficiaryId,
                                    beneficiaryAddress : finalData[0].lcorder.beneficiaryAddress,
                                    lcType : finalData[0].lcorder.lcType,
                                    lcCurrency : finalData[0].lcorder.lcCurrency,
                                    lcAmount :  finalData[0].lcorder.lcAmount,
                                    lcAmountTemp : finalData[0].lcorder.lcAmount,
                                    lcIssueDate : finalData[0].lcorder.lcIssueDate,
                                    lcExpiryPlace : finalData[0].lcorder.lcExpiryPlace,
                                    latestShipmentDate : finalData[0].lcorder.latestShipmentDate,
                                    liabilityReversalDate : finalData[0].lcorder.liabilityReversalDate,
                                    advisingBankID : finalData[0].lcorder.advisingBankID,
                                    applicantBank : finalData[0].lcorder.applicantBank,
                                    applicantBankAddress : finalData[0].lcorder.applicantBankAddress,
                                    advisingBankAddress : finalData[0].lcorder.advisingBankAddress,
                                    formofDocumentaryCredit : finalData[0].lcorder.formofDocumentaryCredit,
                                    documentaryCreditNumber : finalData[0].lcorder.documentaryCreditNumber,
                                    availableWithBy : finalData[0].lcorder.availableWithBy,
                                    forTransportationTo : finalData[0].lcorder.forTransportationTo,
                                    descriptionOfGoodsAndOrServices : finalData[0].lcorder.descriptionOfGoodsAndOrServices,
                                    additionalConditions : finalData[0].lcorder.additionalConditions,
                                    periodForPresentation : finalData[0].lcorder.periodForPresentation,
                                    advisingThroughBank : finalData[0].lcorder.advisingThroughBank,
                                    transshipment : finalData[0].lcorder.transshipment,
                                    portofLoading : finalData[0].lcorder.portofLoading,
                                    maximumCreditAmount : finalData[0].lcorder.maximumCreditAmount,
                                    draftsAt : finalData[0].lcorder.draftsAt,
                                    partialShipments : finalData[0].lcorder.partialShipments,
                                    senderToReceiverInformation : finalData[0].lcorder.senderToReceiverInformation,
                                    charges : finalData[0].lcorder.charges,
                                    confirmationInstructions : finalData[0].lcorder.confirmationInstructions,
                                    sequenceOfTotal : finalData[0].lcorder.sequenceOfTotal,
                                    documentsRequired : finalData[0].lcorder.documentsRequired,
                                    draftsAtSight:finalData[0].lcorder.draftsAtSight,
                                    draftsAtUsance:finalData[0].lcorder.draftsAtUsance,
                                    shipmentPeriodSight:finalData[0].lcorder.shipmentPeriodSight,
                                    shipmentPeriodUsance:finalData[0].lcorder.shipmentPeriodUsance,
                                    percentageSight:finalData[0].lcorder.percentageSight,
                                    percentageUsance :finalData[0].lcorder.percentageUsance,
                                    lcAmountSight:finalData[0].lcorder.lcAmountSight,
                                    lcAmountUsance:finalData[0].lcorder.lcAmountUsance,
                                    ibanNumber : finalData[0].lcorder.ibanNumber,
                                    incoTerms : finalData[0].lcorder.incoTerms,
                                    bills : [{
                                          billNo : $scope.billform.billNumb,
                                            billAmount: $scope.billform.billamount,
                                           currencyType: $scope.billform.billcurrency,
                                            billDate : new Date($scope.billform.billdate).toLocaleDateString(),
                                                                              }]
                                 };
                                 console.log("BILL without forming json ",bill);

                                  const createBillEndpoint =
                                          apiBaseURL +
                                          "lodge-bill";
                                  $http.post(createBillEndpoint, angular.toJson(bill)).then(
                                     function(result){
                                      // success callback
                                      console.log("INSIDE SUCCESS FUNCTION");
                                      $location.path("/employeeHome");
                                      displayMessage(result);
                                      }, 
                                      function(result){
                                      // failure callback
                                      console.log("INSIDE ERROR FUNCTION");
                                      displayMessage(result);
                                      });
                              });
               };

                            $scope.cancel = () => {
                                      $location.path("/employeeHome");
                             }


                             $scope.disableBillButton = () =>{
                             console.log("inside disable bill function   ",$scope.billform.billamount,$scope.billform.billdate,$scope.billform.billcurrency);
                             if($scope.billform.billamount == '' || $scope.billform.billdate == '' || $scope.billform.billcurrency != 'USD'){
                             return true;
                             }
                             else {
                             return false;
                             }
                             }


                             displayMessage = (message) => {
                             console.log("message in display message--->",message);
                             $rootScope.messageStatus = message.status;
                             const modalInstanceTwo = $uibModal.open({
                                         templateUrl: 'messageContent.html',
                                         controller: 'messageCtrl',
                                         controllerAs: 'modalInstanceTwo',
                                         resolve: { message: () => message }
                                     });

                                     modalInstanceTwo.result.then(() => {}, () => {});
                                 };

        };
        })
        //End
    app.directive('uploadFiles', function () {
       return {
           scope: true,        //create a new scope
           link: function (scope, el, attrs) {
               el.bind('change', function (event) {
                   var files = event.target.files;
                   //iterate files since 'multiple' may be specified on the element
                   for (var i = 0; i < files.length; i++) {
                       //emit event upward
                       scope.$emit("seletedFile", { file: files[i] });
                   }
               });
           }
       };
   });
