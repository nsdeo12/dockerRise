//AMEND STARTS HERE
   app.controller('amendController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore,$filter) {
   if($cookieStore.get('customer')){
                     $scope.message = 'Amend Letter of Credits ';
                     $scope.node = $rootScope.thisNode;
                      $scope.username = $cookieStore.get('customer');
                      console.log("AmendID ID ===>",$rootScope.AmendID,"  node is ",$scope.node," username is ",$scope.username);
                      const LCReqNumb = $rootScope.ID;

                         $scope.logout = function(){
                         $cookieStore.remove('customer');
                         $location.path("/customer");
                             };
                         $scope.lcAmendForm = {};
                         $scope.formError = false;

                     const apiBaseURL = $rootScope.apiBaseURL;
                    const LCAmendRequestId = $rootScope.lcRequestID;
                     //const getObj = apiBaseURL + "lc-orders";
                     const cusID1 = $cookieStore.get('customer');
                     const getObj = apiBaseURL + "customer-lc-orders/"+cusID1;

                     $http.get(getObj).then(function(response){
                     var finalData = response.data;
                     console.log("RESPONSE DATA ", finalData);
                  var finaldatalength= finalData.length;
                  console.log("finaldatalength DATA ", finaldatalength);
                  for (i=0; i<finaldatalength; i++){

                    const selectlcid= $rootScope.AmendID;
                    console.log("selectlcid----",selectlcid);
                    const amendid =finalData[i].lcorder.lcId;
                     console.log("amendid----",amendid);
                  if (selectlcid == amendid){
                    const index = 0;
                    $rootScope.index = i;
                    // console.log("RESPONSE DATA in amend ----->", finalData.lcorder.finalData[i]);
                     $scope.lcRequestID = finalData[i].lcorder.lcReqId;

                       $scope.lcAmendForm.lcamendId = finalData[i].lcorder.lcId;
                            const LCRequestId = $rootScope.lcRequestID;
                            const numberOfAmendment=finalData[i].lcorder.lcNumberOfAmendment+1;
                            $rootScope.numberOfAmendment = numberOfAmendment;
                        const lcamendrequestID = "LC-REQ-"+LCRequestId+"-00"+numberOfAmendment;
                        $scope.lcAmendForm.lcamendreq =  lcamendrequestID;

                        var expdt = finalData[i].lcorder.lcExpiryDate;
                        console.log("expdt---",expdt);
                        console.log("hi");

                     var pattern = /(\d{2})(\d{2})(\d{4})/;
                        $scope.lcAmendForm.lcamendexpirydate = new Date(expdt.replace(pattern, '$1-$2-$3'));
                       $scope.lcAmendForm.amendmodeofshipment =  finalData[i].lcorder.modeOfShipment;
                        $scope.lcAmendForm.lcamendamount =  finalData[i].lcorder.lcAmount;
                       $scope.lcAmendForm.lcamendexpiryplace = finalData[i].lcorder.lcExpiryPlace;
                       //$scope.lcAmendForm.beneficiarybank = finalData[i].lcorder.advisingBankID;

                        //$scope.lcAmendForm.amendmentdetails = finalData[i].lcorder.lcAmendmentDetails;

                        //form assign start here

                        $scope.lcAmendForm.lcId = finalData[i].lcorder.lcId;
                        $scope.lcAmendForm.applicant = finalData[i].lcorder.applicantCustomer;
                        $scope.lcAmendForm.applicantaddress = finalData[i].lcorder.applicantAddress;
                        $scope.lcAmendForm.shipmentperiod =  finalData[i].lcorder.shipmentPeriod;
                        $scope.lcAmendForm.lcexpirydate = finalData[i].lcorder.lcExpiryDate;
                        $scope.lcAmendForm.modeofshipment =  finalData[i].lcorder.modeOfShipment;
                        $scope.lcAmendForm.beneficiary = finalData[i].lcorder.beneficiaryId;
                        $scope.lcAmendForm.beneficiaryaddress = finalData[i].lcorder.beneficiaryAddress;
                        $scope.lcAmendForm.lctype = finalData[i].lcorder.lcType;
                        $scope.lcAmendForm.lccurrency = finalData[i].lcorder.lcCurrency;
                        $scope.lcAmendForm.lcamount =  finalData[i].lcorder.lcAmount;
                        $scope.lcAmendForm.lcissuedate = finalData[i].lcorder.lcIssueDate;
                        $scope.lcAmendForm.lcexpiryplace = finalData[i].lcorder.lcExpiryPlace;
                        $scope.lcAmendForm.shipmentdate = finalData[i].lcorder.latestShipmentDate;
                        $scope.lcAmendForm.liabilitydate = finalData[i].lcorder.liabilityReversalDate;
                        $scope.lcAmendForm.beneficiarybank = finalData[i].lcorder.advisingBankID;
                        $scope.lcAmendForm.applicantBank = finalData[i].lcorder.applicantBank;
                        $scope.lcAmendForm.applicantBankAddress = finalData[i].lcorder.applicantBankAddress;
                        $scope.lcAmendForm.beneficiarybankaddress = finalData[i].lcorder.advisingBankAddress;
                        $scope.lcAmendForm.DocumentaryCredit = finalData[i].lcorder.formofDocumentaryCredit;
                        $scope.lcAmendForm.CreditNumber = finalData[i].lcorder.documentaryCreditNumber;
                        $scope.lcAmendForm.AvailableWith = finalData[i].lcorder.availableWithBy;
                        $scope.lcAmendForm.TransportationTo = finalData[i].lcorder.forTransportationTo;
                        $scope.lcAmendForm.DescOfGoods = finalData[i].lcorder.descriptionOfGoodsAndOrServices;
                        $scope.lcAmendForm.additionalConditions = finalData[i].lcorder.additionalConditions;
                        $scope.lcAmendForm.PeriodForPresentaion = finalData[i].lcorder.periodForPresentation;
                        $scope.lcAmendForm.AdvisingThroughBank = finalData[i].lcorder.advisingThroughBank;
                        $scope.lcAmendForm.transhipment = finalData[i].lcorder.transshipment;
                        $scope.lcAmendForm.PortofLoading = finalData[i].lcorder.portofLoading;
                        $scope.lcAmendForm.MaxCreditAmount = finalData[i].lcorder.maximumCreditAmount;
                        $scope.lcAmendForm.DraftsAt = finalData[i].lcorder.draftsAt;
                        $scope.lcAmendForm.PartialShipments = finalData[i].lcorder.partialShipments;
                        $scope.lcAmendForm.SenderToReceiverInfo = finalData[i].lcorder.senderToReceiverInformation;
                        $scope.lcAmendForm.Charges = finalData[i].lcorder.charges;
                        $scope.lcAmendForm.ConfirmationInstruction = finalData[i].lcorder.confirmationInstructions;
                        $scope.lcAmendForm.SequenceTotal = finalData[i].lcorder.sequenceOfTotal;
                        $scope.lcAmendForm.DocRequired = finalData[i].lcorder.documentsRequired;
                        $scope.lcAmendForm.iban = finalData[i].lcorder.ibanNumber;
                        $scope.lcAmendForm.incoTerms=finalData[i].lcorder.incoTerms;
                //New Changes:24-03-2017 : Deepak:Begin
                         $scope.lcAmendForm.DraftsAt_sight=	finalData[i].lcorder.draftsAtSight;
                         $scope.lcAmendForm.DraftsAt_usance=	finalData[i].lcorder.draftsAtUsance;
                         $scope.lcAmendForm.shipmentperiod_sight=	finalData[i].lcorder.shipmentPeriodSight;
                         $scope.lcAmendForm.shipmentperiod_usance=	finalData[i].lcorder.shipmentPeriodUsance;
                         $scope.lcAmendForm.Percentage_sight=	finalData[i].lcorder.percentageSight;
                         $scope.lcAmendForm.Percentage_usance=	finalData[i].lcorder.percentageUsance;
                         $scope.lcAmendForm.lcamount_sight=	finalData[i].lcorder.lcAmountSight;
                         $scope.lcAmendForm.lcamount_usance=	finalData[i].lcorder.lcAmountUsance;
                //New Changes:24-03-2017 : Deepak:END

                        $scope.lcAmendAmountcheck = () =>  {
         console.log("LC AMOUNT",$scope.lcAmendForm.lcamendamount);
                        var value = $scope.lcAmendForm.lcamendamount;
                       
                        var Amtval = value.split(/^([-+]?[0-9]*\.?[0-9]+)([abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ])$/);
                        console.log("AMT VAL  ",Amtval);

                        if(Amtval[2].toLowerCase()=='m'|| Amtval[2].toLowerCase()=='h'|| Amtval[2].toLowerCase()=='t'){

                        if(Amtval[2].toLowerCase()== "m"){
                        $scope.lcAmendForm.lcamendamount = Amtval[1]*1000000;
                        }
                        else if(Amtval[2].toLowerCase()== "h")
                        {
                        $scope.lcAmendForm.lcamendamount = Amtval[1]*100;
                        }
                        else if(Amtval[2].toLowerCase()== "t")
                        {
                        $scope.lcAmendForm.lcamendamount = Amtval[1]*1000;
                        }
                        else {
                        $scope.lcAmendForm.lcamendamount = $scope.lcAmendForm.lcamendamount;
                        }
                        }
                        else{
                        console.log("inside check else");
                        $scope.lcAmendForm.lcamendamount = "";

                        }
    }
                        //end here
                        
                       } } });
                         console.log("Before scope");

                $scope.changelcamendfields= () => {

                //lc amount chnge logic

//end

                   $http.get(getObj).then(function(response){
                   var finalData = response.data;
                   console.log("RESPONSE DATA inside ", finalData);
                   console.log("$rootScope.index value", $rootScope.index);
                   console.log("RESPONSE DATA in amend insdi ----->", finalData[$rootScope.index].lcorder,finalData[$rootScope.index]);


                   $scope.oldvaluefromcorda = {
                                expirydate : finalData[$rootScope.index].lcorder.lcExpiryDate,
                                modeofshipment :  finalData[$rootScope.index].lcorder.modeOfShipment,
                                lcamount : finalData[$rootScope.index].lcorder.lcAmount,
                                lcexpiryplace : finalData[$rootScope.index].lcorder.lcExpiryPlace,
                                advisingbankref : finalData[$rootScope.index].lcorder.advisingBankID,
                                    }
console.log("oldvaluefromcorda-inside--->",$scope.oldvaluefromcorda);

                 $scope.fieldvaluefromUI = {

                           lcAmendAmountfieldlevel: $scope.lcAmendForm.lcamendamount,
                           amendModeOfShipmentfieldlevel : $scope.lcAmendForm.amendmodeofshipment,
                           lcAmendExpiryDatefieldlevel : new Date($scope.lcAmendForm.lcamendexpirydate).toLocaleDateString(),
                           lcAmendExpiryPlacefieldlevel : $scope.lcAmendForm.lcamendexpiryplace,
                           lcAmendAdvisingBankReffieldlevel : $scope.lcAmendForm.amendbeneficiarybank,

                        }
                    console.log("fieldvaluefromUI---->",$scope.fieldvaluefromUI);
$scope.lccheck= () => {


if($scope.oldvaluefromcorda.expirydate == $scope.fieldvaluefromUI. lcAmendExpiryDatefieldlevel && $scope.oldvaluefromcorda.modeofshipment==$scope.fieldvaluefromUI.amendModeOfShipmentfieldlevel&& $scope.oldvaluefromcorda.lcamount == $scope.fieldvaluefromUI.lcAmendAmountfieldlevel&&$scope.oldvaluefromcorda.lcexpiryplace==$scope.fieldvaluefromUI.lcAmendExpiryPlacefieldlevel){
console.log("inside if amend");

return false;
}
else {
console.log("inside else amend");
return true;
}

}


         });
         }






                     $scope.amendLC = () => {

                         const amendLOC = {
                           lcAmendId : $scope.lcAmendForm.lcamendId,
                           lcAmendReqId : $scope.lcAmendForm.lcamendreq,
                           //lcAmendExpiryDate : $scope.lcAmendForm.lcexpirydate,
                           numberOfAmendment : $rootScope.numberOfAmendment,
                          lcAmendExpiryDate : new Date($scope.lcAmendForm.lcamendexpirydate).toLocaleDateString(),
                           amendModeOfShipment : $scope.lcAmendForm.amendmodeofshipment,
                           lcAmendAmount : $scope.lcAmendForm.lcamendamount,
                           lcAmendExpiryPlace : $scope.lcAmendForm.lcamendexpiryplace,
                           lcAmendAdvisingBankRef : $scope.lcAmendForm.amendbeneficiarybank,
                            amendmentDetails: $scope.lcAmendForm.amendmentdetails,
                            status : "AmendRequested"
                                                       //status : "APPROVED"
                                 };

                                 if($scope.lcAmendForm.amendbeneficiarybank == null){
                                                                      alert("Advising Bank Ref Cannot Be Empty");
                                                                  }
                                 else{
                                 console.log("amendloc value---",amendLOC);
                                     const amendLCEndpoint = apiBaseURL +"lcamendreq";
                            //console.log("approve LOC object  ",approveLOC);
                                    $http.post(amendLCEndpoint, angular.toJson(amendLOC)).then(
                                    function(result){
                                     // success callback
                                     console.log("INSIDE SUCCESS FUNCTION");
                                     $location.path("/customerHome");
                                     displayMessage(result);
                                     },
                                     function(result){
                                     // failure callback
                                     console.log("INSIDE ERROR FUNCTION");
                                     displayMessage(result);
                                        }
                                     );
                                 }
                         }
                         $scope.cancel = () => {
                               $location.path("/customerHome");
                         }
                         displayMessage = (message) => {
                         console.log("message in display message--->",message);
                         $rootScope.messageStatus = message.status;
                                 const modalInstanceTwo = $uibModal.open({
                                     templateUrl: 'messageContent.html',
                                     controller: 'messageCtrl',
                                     controllerAs: 'modalInstanceTwo',
                                     resolve: { message: () => message }
                                 });
                                 modalInstanceTwo.result.then(() => {}, () => {});
                             };
                         function invalidFormInput() {
                        //     const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                     //            || !modalInstance.form.deliveryDate
                     //            || !modalInstance.form.city
                     //            || !modalInstance.form.country;
                     //
                     //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                     //
                     //        const invalidItemFields = modalInstance.items
                     //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                     //            .reduce((prev, curr) => prev && curr);

                        //     return invalidNonItemFields;
                         }
                        }
                                                 else{
                                                 $location.path("/customer");
                                                 }

                   });





 //End