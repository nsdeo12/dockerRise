//=================================================================================================================================================================
//AMEND ACCEPT CONTROLLER START HERE
//=================================================================================================================================================================
//Amend start here
app.controller('amendAcceptController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore) {
  if($cookieStore.get('employee')){
                    $scope.message = 'Accept Amended Letter of Credits ';
                    $scope.node = $rootScope.thisNode;
                     $scope.username = $cookieStore.get('employee');
                     console.log("AMENDING ID ===>",$rootScope.AmendID,"  node is ",$scope.node," username is ",$scope.username);
                     //const LCAmendNumb = $rootScope.AmendID;


                        $scope.logout = function(){
                        $cookieStore.remove('employee');
                        $location.path("/customer");
                            };
                        $scope.lcAmendAcceptForm = {};
                        $scope.formError = false;

                    const LCAmendId = $rootScope.AmendID;
                    const LCAmendReqNumb = $rootScope.AmendReqID;

                    const apiBaseURL = $rootScope.apiBaseURL;
                    //const getObj = apiBaseURL + "lc-orders";
                    const cusID1 = $cookieStore.get('employee');
                    const getObj = apiBaseURL + "employee-lc-orders/"+LCAmendId;

                    const getAmendObj = apiBaseURL + "lcamendreq/"+LCAmendReqNumb;

                    //start retrieving here


                    $http.get(getAmendObj).then(function(response){
                                        var finalAmendData = response.data;
                                        console.log("db data in amendAccept Controller ", finalAmendData);

                                          //amend part start here

                                          $scope.lcAmendAcceptForm.LcAmendId = finalAmendData.lcAmendId;
                                          $scope.lcAmendAcceptForm.LcAmendReqId = finalAmendData.lcAmendReqId;
                                          $scope.lcAmendAcceptForm.NumberOfAmendment = finalAmendData.numberOfAmendment;
                                          $scope.lcAmendAcceptForm.LcAmendAmount = finalAmendData.lcAmendAmount;
                                          $scope.lcAmendAcceptForm.LcAmendAdvisingBankRef = finalAmendData.lcAmendAdvisingBankRef;
                                          $scope.lcAmendAcceptForm.AmendModeOfShipment = finalAmendData.amendModeOfShipment;

                                          var pattern = /(\d{2})(\d{2})(\d{4})/;
                                          $scope.lcAmendAcceptForm.LcAmendExpiryDate = new Date(finalAmendData.lcAmendExpiryDate.replace(pattern, '$1-$2-$3'));

                                          $scope.lcAmendAcceptForm.LcAmendExpiryPlace = finalAmendData.lcAmendExpiryPlace;

                                          $scope.lcAmendAcceptForm.AmendmentDetails = finalAmendData.amendmentDetails;

                    });

                    //end here

                    $http.get(getObj).then(function(response){
                    var finalData = response.data;
                    console.log("corda data in amendAcceptController ", finalData[0]);
                    $scope.lcRequestID = finalData[0].lcorder.lcReqId;
                      $scope.lcAmendAcceptForm.lcId = finalData[0].lcorder.lcId;
                      $scope.lcAmendAcceptForm.applicant = finalData[0].lcorder.applicantCustomer;
                      $scope.lcAmendAcceptForm.applicantaddress = finalData[0].lcorder.applicantAddress;
                      $scope.lcAmendAcceptForm.shipmentperiod =  finalData[0].lcorder.shipmentPeriod;
                      $scope.lcAmendAcceptForm.lcexpirydate = finalData[0].lcorder.lcExpiryDate;
                      $scope.lcAmendAcceptForm.modeofshipment =  finalData[0].lcorder.modeOfShipment;
                      $scope.lcAmendAcceptForm.beneficiary = finalData[0].lcorder.beneficiaryId;
                      $scope.lcAmendAcceptForm.beneficiaryaddress = finalData[0].lcorder.beneficiaryAddress;
                      $scope.lcAmendAcceptForm.lctype = finalData[0].lcorder.lcType;
                      $scope.lcAmendAcceptForm.lccurrency = finalData[0].lcorder.lcCurrency;
                      $scope.lcAmendAcceptForm.lcamount =  finalData[0].lcorder.lcAmount;
                      $scope.lcAmendAcceptForm.lcissuedate = finalData[0].lcorder.lcIssueDate;
                      $scope.lcAmendAcceptForm.lcexpiryplace = finalData[0].lcorder.lcExpiryPlace;
                      $scope.lcAmendAcceptForm.shipmentdate = finalData[0].lcorder.latestShipmentDate;
                      $scope.lcAmendAcceptForm.liabilitydate = finalData[0].lcorder.liabilityReversalDate;
                      $scope.lcAmendAcceptForm.beneficiarybank = finalData[0].lcorder.advisingBankID;
                      $scope.lcAmendAcceptForm.applicantBank = finalData[0].lcorder.applicantBank;
                      $scope.lcAmendAcceptForm.applicantBankAddress = finalData[0].lcorder.applicantBankAddress;
                      $scope.lcAmendAcceptForm.beneficiarybankaddress = finalData[0].lcorder.advisingBankAddress;
                      $scope.lcAmendAcceptForm.DocumentaryCredit = finalData[0].lcorder.formofDocumentaryCredit;
                      $scope.lcAmendAcceptForm.CreditNumber = finalData[0].lcorder.documentaryCreditNumber;
                      $scope.lcAmendAcceptForm.AvailableWith = finalData[0].lcorder.availableWithBy;
                      $scope.lcAmendAcceptForm.TransportationTo = finalData[0].lcorder.forTransportationTo;
                      $scope.lcAmendAcceptForm.DescOfGoods = finalData[0].lcorder.descriptionOfGoodsAndOrServices;
                      $scope.lcAmendAcceptForm.additionalConditions = finalData[0].lcorder.additionalConditions;
                      $scope.lcAmendAcceptForm.PeriodForPresentaion = finalData[0].lcorder.periodForPresentation;
                      $scope.lcAmendAcceptForm.AdvisingThroughBank = finalData[0].lcorder.advisingThroughBank;
                      $scope.lcAmendAcceptForm.transhipment = finalData[0].lcorder.transshipment;
                      $scope.lcAmendAcceptForm.PortofLoading = finalData[0].lcorder.portofLoading;
                      $scope.lcAmendAcceptForm.MaxCreditAmount = finalData[0].lcorder.maximumCreditAmount;
                      $scope.lcAmendAcceptForm.DraftsAt = finalData[0].lcorder.draftsAt;
                      $scope.lcAmendAcceptForm.PartialShipments = finalData[0].lcorder.partialShipments;
                      $scope.lcAmendAcceptForm.SenderToReceiverInfo = finalData[0].lcorder.senderToReceiverInformation;
                      $scope.lcAmendAcceptForm.Charges = finalData[0].lcorder.charges;
                      $scope.lcAmendAcceptForm.ConfirmationInstruction = finalData[0].lcorder.confirmationInstructions;
                      $scope.lcAmendAcceptForm.SequenceTotal = finalData[0].lcorder.sequenceOfTotal;
                      $scope.lcAmendAcceptForm.DocRequired = finalData[0].lcorder.documentsRequired;
                      $scope.lcAmendAcceptForm.iban = finalData[0].lcorder.ibanNumber;
                      $scope.lcAmendAcceptForm.incoTerms=finalData[0].lcorder.incoTerms;
                  //New Changes:24-03-2017 : Deepak:Begin
                       $scope.lcAmendAcceptForm.DraftsAt_sight=	finalData[0].lcorder.draftsAtSight;
                       $scope.lcAmendAcceptForm.DraftsAt_usance=finalData[0].lcorder.draftsAtUsance;
                       $scope.lcAmendAcceptForm.shipmentperiod_sight=finalData[0].lcorder.shipmentPeriodSight;
                       $scope.lcAmendAcceptForm.shipmentperiod_usance=finalData[0].lcorder.shipmentPeriodUsance;
                       $scope.lcAmendAcceptForm.Percentage_sight=finalData[0].lcorder.percentageSight;
                       $scope.lcAmendAcceptForm.Percentage_usance=finalData[0].lcorder.percentageUsance;
                       $scope.lcAmendAcceptForm.lcamount_sight=	finalData[0].lcorder.lcAmountSight;
                       $scope.lcAmendAcceptForm.lcamount_usance=finalData[0].lcorder.lcAmountUsance;
                //New Changes:24-03-2017 : Deepak:END
                        });


                    $scope.amendAcceptLC = () => {

                    const amendAcceptLOC = {
                          lcId : $scope.lcAmendAcceptForm.lcId,
                          //lcReqId : $scope.lcRequestID,$scope.lcAmendAcceptForm.LcAmendReqId
                          lcReqId : $scope.lcAmendAcceptForm.LcAmendReqId,
                          applicantCustomer : $scope.lcAmendAcceptForm.applicant,
                          applicantAddress : $scope.lcAmendAcceptForm.applicantaddress,
                          beneficiaryId : $scope.lcAmendAcceptForm.beneficiary,
                          beneficiaryAddress : $scope.lcAmendAcceptForm.beneficiaryaddress,
                          lcType : $scope.lcAmendAcceptForm.lctype,
                          lcCurrency : $scope.lcAmendAcceptForm.lccurrency,
                          lcIssueDate : $scope.lcAmendAcceptForm.lcissuedate,
                          latestShipmentDate : $scope.lcAmendAcceptForm.shipmentdate,
                          liabilityReversalDate : $scope.lcAmendAcceptForm.liabilitydate,
                          applicantBank : $scope.lcAmendAcceptForm.applicantBank,
                          applicantBankAddress : $scope.lcAmendAcceptForm.applicantBankAddress,
                          advisingBankAddress : $scope.lcAmendAcceptForm.beneficiarybankaddress,
                          formofDocumentaryCredit : $scope.lcAmendAcceptForm.DocumentaryCredit,
                          documentaryCreditNumber : $scope.lcAmendAcceptForm.CreditNumber,
                          availableWithBy : $scope.lcAmendAcceptForm.AvailableWith,
                          forTransportationTo : $scope.lcAmendAcceptForm.TransportationTo,
                          descriptionOfGoodsAndOrServices : $scope.lcAmendAcceptForm.DescOfGoods,
                          additionalConditions : $scope.lcAmendAcceptForm.additionalConditions,
                          periodForPresentation : $scope.lcAmendAcceptForm.PeriodForPresentaion,
                          advisingThroughBank : $scope.lcAmendAcceptForm.AdvisingThroughBank,
                          amendAdvisingBankRef : $scope.lcAmendAcceptForm.LcAmendAdvisingBankRef,
                          transshipment : $scope.lcAmendAcceptForm.transhipment,
                          portofLoading : $scope.lcAmendAcceptForm.PortofLoading,
                          maximumCreditAmount : $scope.lcAmendAcceptForm.MaxCreditAmount,
                          draftsAt : $scope.lcAmendAcceptForm.DraftsAt,
                          partialShipments : $scope.lcAmendAcceptForm.PartialShipments,
                          senderToReceiverInformation : $scope.lcAmendAcceptForm.SenderToReceiverInfo,
                          charges : $scope.lcAmendAcceptForm.Charges,
                          confirmationInstructions : $scope.lcAmendAcceptForm.ConfirmationInstruction,
                          sequenceOfTotal : $scope.lcAmendAcceptForm.SequenceTotal,
                          //documentsRequired : docrec1,
                          ibanNumber : $scope.lcAmendAcceptForm.iban,
                          incoTerms:$scope.lcAmendAcceptForm.incoTerms,

                          documentsRequired: $scope.lcAmendAcceptForm.DocRequired,

                          shipmentPeriod : $scope.lcAmendAcceptForm.shipmentperiod,
                          lcExpiryDate : new Date($scope.lcAmendAcceptForm.LcAmendExpiryDate).toLocaleDateString(),
                          modeOfShipment : $scope.lcAmendAcceptForm.AmendModeOfShipment,
                          lcAmount : $scope.lcAmendAcceptForm.LcAmendAmount,
                          lcExpiryPlace :  $scope.lcAmendAcceptForm.LcAmendExpiryPlace,
                          lcNumberOfAmendment : $rootScope.version,
                          lcAmendmentDetails : $scope.lcAmendAcceptForm.AmendmentDetails,
                          advisingBankID : $scope.lcAmendAcceptForm.beneficiarybank,
                          lcAmountTemp : $scope.lcAmendAcceptForm.LcAmendAmount,
                            //New Changes:24-03-2017 : Deepak:Begin

                                draftsAtSight : $scope.lcAmendAcceptForm.DraftsAt_sight,
                                draftsAtUsance: $scope.lcAmendAcceptForm.DraftsAt_usance,
                                shipmentPeriodSight: $scope.lcAmendAcceptForm.shipmentperiod_sight,
                                shipmentPeriodUsance:$scope.lcAmendAcceptForm.shipmentperiod_usance,
                                percentageSight: $scope.lcAmendAcceptForm.Percentage_sight,
                                percentageUsance: $scope.lcAmendAcceptForm.Percentage_usance,
                                lcAmountSight:$scope.lcAmendAcceptForm.lcamount_sight,
                                lcAmountUsance:$scope.lcAmendAcceptForm.lcamount_usance,

                             //New Changes:24-03-2017 : Deepak:END

                          //status : "APPROVED"
                                };
                                    const acceptLCEndpoint =
                                        apiBaseURL +"lc-amend";

console.log("amendAccept LOC object  ",amendAcceptLOC);
                                   $http.post(acceptLCEndpoint, angular.toJson(amendAcceptLOC)).then(
                                   function(result){
                                    // success callback
                                    console.log("INSIDE SUCCESS FUNCTION");
                                    $location.path("/employeeHome");
                                    displayMessage(result);
                                    }, 
                                    function(result){
                                    // failure callback
                                    console.log("INSIDE ERROR FUNCTION");
                                    displayMessage(result);
                                                                         }
                                        //(result) => displayMessage(result),
                                        //(result) => displayMessage(result)
                                    );
                                    // console.log("LC approved and the object is  ",approveLoc);
                                     //console.log("message status" , $scope.messageStatus);
                                     //$location.path("/home");
                        }
                        $scope.cancel = () => {
                              $location.path("/employeeHome");
                        }
                        displayMessage = (message) => {
                        console.log("message in display message--->",message);
                        $rootScope.messageStatus = message.status;
                                const modalInstanceTwo = $uibModal.open({
                                    templateUrl: 'messageContent.html',
                                    controller: 'messageCtrl',
                                    controllerAs: 'modalInstanceTwo',
                                    resolve: { message: () => message }
                                });

                                modalInstanceTwo.result.then(() => {}, () => {});
                            };

                        function invalidFormInput() {
                            const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                    //            || !modalInstance.form.deliveryDate
                    //            || !modalInstance.form.city
                    //            || !modalInstance.form.country;
                    //
                    //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                    //
                    //        const invalidItemFields = modalInstance.items
                    //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                    //            .reduce((prev, curr) => prev && curr);

                            return invalidNonItemFields;
                        }
                        }
                                                else{
                                                $location.path("/customer");
                                                }

                  });
//====================================================================================================================================================================================
//AMEND ACCEPT CONTROLLER END HERE
//====================================================================================================================================================================================
