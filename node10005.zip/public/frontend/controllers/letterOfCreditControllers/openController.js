  
  
  
  //---------------------------------------------------------------------------------------------------------------------------------------------
  //LC Open code after lc request from customer
  //---------------------------------------------------------------------------------------------------------------------------------------------
  //Start
         app.controller('openController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore,rootValues,shareid) {
         if($cookieStore.get('employee')){

          //  $scope.id = rootValues.data1;
          // console.log("rootID",$scope.id);
          $scope.test=shareid.ID;
          var sub=$scope.test;
           var lcRequestID=sub.substring(7);

          console.log("id in open",  lcRequestID);


                            $scope.message = 'Open Letter of Credits ';
                            $scope.IsDocReqDisabled = true;
                            $scope.node = $rootScope.thisNode;
                            $scope.username = $cookieStore.get('employee');
							          //console.log("$rootScope.ID:",$rootScope.ID12);
                          //  console.log("OPENING ID ===>",$rootScope.ID ," node is ",$scope.node," username is ",$scope.username);
                            const LCRequestId = lcRequestID;
                                $scope.lcOpenForm = {};
                                $scope.formError = false;
                            $scope.logout = function(){
                            $cookieStore.remove('employee');
                            $location.path("/customer");
                                };

                         $scope.checkIsDocReqDisabled = function() {
                         console.log("checkIsDocReqDisabled --->",$scope.lcOpenForm.DocRequired);
                         if($scope.lcOpenForm.DocRequired != null )
                        {
                         $scope.IsDocReqDisabled = false;
                         }
                         else
                          {
                          $scope.IsDocReqDisabled = true;
                          }
                         console.log("$scope.lcForm.IsDocReqDisabled --->",$scope.IsDocReqDisabled);
                         };


                            const LCReqNumb =lcRequestID;
                            //const apiBaseURL = $rootScope.apiBaseURL;
							const nodePort = $location.port();
							const apiBaseURL = "http://"+window.__env.apiUrl+":" + nodePort + "";

                            const getObj = apiBaseURL + "/lcreq/" + sub;

                  console.log("url path --->",getObj);


                                $http.get(getObj).then(function(response){
                                var modelData = response.data;

                                  console.log("RESPONSE DATA ", modelData);
                                console.log("RESPONSE DATA1 ", modelData[0].shipmentperiodsight);

                                $scope.lcOpenForm.lcId= "LC-"+shareid.lcIDnew ;
                                $scope.lcOpenForm.applicant=	modelData[0].applicantcustomer;
                                $scope.lcOpenForm.applicantaddress=	modelData[0].applicantaddress;
                                //$scope.lcOpenForm.presentationdays=	modelData.presentationdays;
                                $scope.lcOpenForm.shipmentperiod=	modelData[0].shipmentPeriod;
                                $scope.lcOpenForm.lcexpirydate=	modelData[0].lcexpirydate;
                                $scope.lcOpenForm.modeofshipment=	modelData[0].modeofshipment;
                                $scope.lcOpenForm.beneficiary=	modelData[0].beneficiaryId;
                                $scope.lcOpenForm.beneficiaryaddress=	modelData[0].beneficiaryaddress;
                                $scope.lcOpenForm.lctype=	modelData[0].lctype;
                                $scope.lcOpenForm.lccurrency=	modelData[0].lccurrency;
                                $scope.lcOpenForm.lcamount=	modelData[0].lcamount;
                                $scope.lcOpenForm.lcissuedate=	new Date(modelData[0].lcissuedate).toLocaleDateString();
                                $scope.lcOpenForm.lcexpiryplace=	modelData[0].lcexpiryplace;
                                $scope.lcOpenForm.shipmentdate=	new Date(modelData[0].latestshipmentdate).toLocaleDateString();
                                $scope.lcOpenForm.liabilitydate=	new Date(modelData[0].liabilityreversaldate).toLocaleDateString();
                                $scope.lcOpenForm.beneficiarybank=	modelData[0].advisingbankid;
                                $scope.lcOpenForm.applicantBank=	modelData[0].applicantbank;
                                $scope.lcOpenForm.applicantBankAddress=	modelData[0].applicantbankaddress;
                                $scope.lcOpenForm.beneficiarybankaddress=	modelData[0].advisingBankAddress;
                                $scope.lcOpenForm.DocumentaryCredit=	modelData[0].formofdocumentarycredit;
                                $scope.lcOpenForm.CreditNumber=	"LC-"+shareid.lcIDnew;
                                $scope.lcOpenForm.AvailableWith=	modelData[0].availablewithby;
                                $scope.lcOpenForm.TransportationTo=	modelData[0].fortransportationto;
                                $scope.lcOpenForm.DescOfGoods=	modelData[0].descriptionofgoodsandorservices;
                                $scope.lcOpenForm.additionalConditions=	modelData[0].additionalConditions;
                                $scope.lcOpenForm.PeriodForPresentaion=	modelData[0].periodforpresentation;
                                $scope.lcOpenForm.AdvisingThroughBank=	modelData[0].advisingthroughbank;
                                $scope.lcOpenForm.transhipment=	modelData[0].transshipment;
                                //$scope.lcOpenForm.TakingCharge=	modelData.onboardordisportakingcharge;
                                $scope.lcOpenForm.PortofLoading=	modelData[0].portofloading;

                                //$scope.lcOpenForm.TakingCharge=	modelData.onboardordisportakingcharge;
                                $scope.lcOpenForm.MaxCreditAmount=	modelData[0].maximumcreditamount;
                                //$scope.lcOpenForm.DraftsAt=	modelData.draftsAt;
                                $scope.lcOpenForm.PartialShipments=	modelData[0].partialshipments;
                                $scope.lcOpenForm.SenderToReceiverInfo=	modelData[0].sendertoreceiverinformation;
                                $scope.lcOpenForm.Charges=	modelData[0].charges;
                                $scope.lcOpenForm.ConfirmationInstruction=	modelData[0].confirmationInstructions;
                                $scope.lcOpenForm.SequenceTotal=	modelData[0].sequenceoftotal;
                                $scope.lcOpenForm.iban=	modelData[0].ibannumber;
                                $scope.lcOpenForm.incoTerms=modelData[0].incoterms;
                                  //New Changes:24-03-2017 : Deepak:Begin
                                 $scope.lcOpenForm.DraftsAt_sight=	modelData[0].draftsatsight;
                                 $scope.lcOpenForm.DraftsAt_usance=	modelData[0].draftsatusance;
                                 $scope.lcOpenForm.shipmentperiod_sight=	parseInt(modelData[0].shipmentperiodsight);
                                 $scope.lcOpenForm.shipmentperiod_usance=	parseInt(modelData[0].shipmentperiodusance);
                                 $scope.lcOpenForm.Percentage_sight=	parseFloat(modelData[0].percentagesight);
                                 $scope.lcOpenForm.Percentage_usance=	parseFloat(modelData[0].percentageusance);
                                 $scope.lcOpenForm.lcamount_sight=	parseFloat(modelData[0].lcAmountsight);
                                 $scope.lcOpenForm.lcamount_usance=	modelData[0].lcAmountusance;
                                  //New Changes:24-03-2017 : Deepak:END

 //--------------------------------------------------------------------------------------
 //Code for document Required
 //--------------------------------------------------------------------------------------
 //Start


 //--------------------------------------------------------------------------------------

//End
                          //"PENDING",	modelData.status

            });
                                //});

           $scope.Open = () => {

                            const openLoc = {

                                       //lcId : $scope.lcOpenForm.lcId,
                                       lcId:"LC-"+shareid.lcIDnew,
									   lcReqId:"LC-REQ-"+LCReqNumb,
                                       applicantCustomer : $scope.lcOpenForm.applicant,
                                       applicantAddress : $scope.lcOpenForm.applicantaddress,
                                       //presentationDays : $scope.lcOpenForm.presentationdays,
                                       //shipmentPeriod : $scope.lcOpenForm.shipmentperiod,
                                       lcExpiryDate : $scope.lcOpenForm.lcexpirydate,
                                       modeOfShipment : $scope.lcOpenForm.modeofshipment,
                                       beneficiaryId : $scope.lcOpenForm.beneficiary,
                                       beneficiaryAddress : $scope.lcOpenForm.beneficiaryaddress,
                                       lcType : $scope.lcOpenForm.lctype,
                                       lcCurrency : $scope.lcOpenForm.lccurrency,
                                       lcAmount : $scope.lcOpenForm.lcamount,
                                       lcAmountTemp:$scope.lcOpenForm.lcamount,
                                       lcIssueDate : $scope.lcOpenForm.lcissuedate,
                                       lcExpiryPlace : $scope.lcOpenForm.lcexpiryplace,
                                       latestShipmentDate : $scope.lcOpenForm.shipmentdate,
                                       liabilityReversalDate : $scope.lcOpenForm.liabilitydate,
                                       advisingBankID : $scope.lcOpenForm.beneficiarybank,
                                       applicantBank : $scope.lcOpenForm.applicantBank,
                                       applicantBankAddress : $scope.lcOpenForm.applicantBankAddress,
                                       advisingBankAddress : $scope.lcOpenForm.beneficiarybankaddress,
                                       formofDocumentaryCredit : $scope.lcOpenForm.DocumentaryCredit,
                                       documentaryCreditNumber : $scope.lcOpenForm.CreditNumber,
                                       availableWithBy : $scope.lcOpenForm.AvailableWith,
                                       forTransportationTo : $scope.lcOpenForm.TransportationTo,
                                       descriptionOfGoodsAndOrServices : $scope.lcOpenForm.DescOfGoods,
                                       additionalConditions : $scope.lcOpenForm.additionalConditions,
                                       periodForPresentation : $scope.lcOpenForm.PeriodForPresentaion,
                                       advisingThroughBank : $scope.lcOpenForm.AdvisingThroughBank,
                                       transshipment : $scope.lcOpenForm.transhipment,
                                       portofLoading : $scope.lcOpenForm.PortofLoading,
                                       maximumCreditAmount : $scope.lcOpenForm.MaxCreditAmount,
                                       draftsAt : $scope.lcOpenForm.DraftsAt,
                                       partialShipments : $scope.lcOpenForm.PartialShipments,
                                       senderToReceiverInformation : $scope.lcOpenForm.SenderToReceiverInfo,
                                       charges : $scope.lcOpenForm.Charges,
                                       confirmationInstructions : $scope.lcOpenForm.ConfirmationInstruction,
                                       sequenceOfTotal : $scope.lcOpenForm.SequenceTotal,
                                       ibanNumber : $scope.lcOpenForm.iban,
                                       incoTerms:$scope.lcOpenForm.incoTerms,


                             //New Changes:24-03-2017 : Deepak:Begin
                                     draftsAtSight:  $scope.lcOpenForm.DraftsAt_sight,
                                      draftsAtUsance: $scope.lcOpenForm.DraftsAt_usance,
                                     shipmentPeriodSight:  $scope.lcOpenForm.shipmentperiod_sight,
                                     shipmentPeriodUsance: $scope.lcOpenForm.shipmentperiod_usance,
                                      percentageSight: $scope.lcOpenForm.Percentage_sight,
                                   percentageUsance:    $scope.lcOpenForm.Percentage_usance,
                                      lcAmountSight: $scope.lcOpenForm.lcamount_sight,
                                     lcAmountUsance:  $scope.lcOpenForm.lcamount_usance ,
                                        //New Changes:24-03-2017 : Deepak:END



                                         documentsRequired : $scope.lcOpenForm.DocRequired,


                                       status : "OPENED"
                                              };

                        const openLCEndpoint =apiBaseURL +"/lc-open";

							console.log("URL in Open ",openLCEndpoint);
							console.log(openLoc);
							
							
                       /*$http.post(openLCEndpoint, angular.toJson(openLoc)).then(
                            (result) => displayMessage(result),
                            (result) => displayMessage(result)
                        );*/
                        $http.post(openLCEndpoint, angular.toJson(openLoc)).then(
                           function(result){
                            console.log("INSIDE SUCCESS FUNCTION",openLoc);
                            $location.path("/employeeHome");
                            displayMessage(result);
                            }, 
                            function(result){
                            // failure callback
                            console.log("INSIDE ERROR FUNCTION");
                            displayMessage(result);
                                                                 }
                                //(result) => displayMessage(result),
                                //(result) => displayMessage(result)
                            );
                         console.log("LC opened and the object is  ",openLoc);

                                }
                                $scope.cancel = () => {
                                      $location.path("/employeeHome");
                                }
                                displayMessage = (message) => {
                                console.log("message in display message--->",message);
                                        const modalInstanceTwo = $uibModal.open({
                                            templateUrl: 'messageContent.html',
                                            controller: 'messageCtrl',
                                            controllerAs: 'modalInstanceTwo',
                                            resolve: { message: () => message }
                                        });

                                        modalInstanceTwo.result.then(() => {}, () => {});
                                    };

                  				  /*
                                function invalidFormInput() {
                                    const invalidNonItemFields = !$scope.lcform.lcrequest
                            //            || isNaN(modalInstance.form.orderNumber)
                            //            || !modalInstance.form.deliveryDate
                            //            || !modalInstance.form.city
                            //            || !modalInstance.form.country;
                            //
                            //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                            //
                            //        const invalidItemFields = modalInstance.items
                            //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                            //            .reduce((prev, curr) => prev && curr);

                                    return invalidNonItemFields;
                                }
                  			  */
                  			  }
                              else{
                              $location.path("/customer");
                              }

                          });

   //End
