//=================================================================================================================================================================
//AMEND APPROVE CONTROLLER START HERE
//=================================================================================================================================================================
//Amend start here
app.controller('amendApproveController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore) {
  if($cookieStore.get('employee')){
                    $scope.message = 'Accept Amended Letter of Credits ';
                    $scope.node = $rootScope.thisNode;
                     $scope.username = $cookieStore.get('employee');
                     console.log("AMENDING ID ===>",$rootScope.AmendID,"  node is ",$scope.node," username is ",$scope.username);
                     //const LCAmendNumb = $rootScope.AmendID;


                        $scope.logout = function(){
                        $cookieStore.remove('employee');
                        $location.path("/customer");
                            };
                        $scope.lcAmendApproveForm = {};
                        $scope.formError = false;

                    const LCAmendId = $rootScope.AmendID;
                    const LCAmendReqNumb = $rootScope.AmendReqID;

                    const apiBaseURL = $rootScope.apiBaseURL;
                    //const getObj = apiBaseURL + "lc-orders";
                    const cusID1 = $cookieStore.get('employee');
                    const getObj = apiBaseURL + "employee-lc-orders/"+LCAmendId;



                    //end here

                    $http.get(getObj).then(function(response){
                    var finalData = response.data;
                    console.log("corda data in amendApproveController ", finalData[0]);
                    //console.log("RESPONSE DATA final", finalData[0].lcorder,finalData[0]);
                    $scope.lcRequestID = finalData[0].lcorder.lcReqId;




 //start here
                    //amend assign part start


                                            //const getAmendApproveObj = "http://"+window.__env.apiUrl+":10005/api/letter-of-credit/lcamendreq/"+$scope.lcRequestID;
                                   /*         const getAmendApproveObj = apiBaseURL+"lcamendreq/"+$scope.lcRequestID;
                                            console.log("URl",getAmendApproveObj);

                                                                //start retrieving here


$http.get(getAmendApproveObj).then(function(response){
                    var finalAmendData = response.data;
                    console.log("response in amendAccept Controller ", response);
                    console.log("db data in amendAccept Controller ", finalAmendData);
                     $scope.lcAmendApproveForm.LcAmendId = finalAmendData.lcAmendId;
                      $scope.lcAmendApproveForm.LcAmendReqId = finalAmendData.lcAmendReqId;
                      $scope.lcAmendApproveForm.NumberOfAmendment = finalAmendData.numberOfAmendment;
                      $scope.lcAmendApproveForm.LcAmendAmount = finalAmendData.lcAmendAmount;
                      $scope.lcAmendApproveForm.LcAmendAdvisingBankRef = finalAmendData.lcAmendAdvisingBankRef;
                      $scope.lcAmendApproveForm.AmendModeOfShipment = finalAmendData.amendModeOfShipment;
                      var pattern = /(\d{2})(\d{2})(\d{4})/;
                      $scope.lcAmendApproveForm.LcAmendExpiryDate = new Date(finalAmendData.lcAmendExpiryDate.replace(pattern, '$1-$2-$3'));
                      $scope.lcAmendApproveForm.LcAmendExpiryPlace = finalAmendData.lcAmendExpiryPlace;
                      $scope.lcAmendApproveForm.AmendmentDetails = finalAmendData.amendmentDetails;


            });
                  */
                      $scope.lcAmendApproveForm.LcAmendId = finalData[0].lcorder.lcId;
                      $scope.lcAmendApproveForm.LcAmendReqId = finalData[0].lcorder.lcReqId;
                      $scope.lcAmendApproveForm.NumberOfAmendment = finalData[0].lcorder.lcNumberOfAmendment;
                      $scope.lcAmendApproveForm.LcAmendAmount = finalData[0].lcorder.lcAmount;
                      $scope.lcAmendApproveForm.LcAmendAdvisingBankRef = finalData[0].lcorder.amendAdvisingBankRef;
                      $scope.lcAmendApproveForm.AmendModeOfShipment = finalData[0].lcorder.modeOfShipment;
                      var pattern = /(\d{2})(\d{2})(\d{4})/;
                      $scope.lcAmendApproveForm.LcAmendExpiryDate = new Date(finalData[0].lcorder.lcExpiryDate.replace(pattern, '$1-$2-$3'));
                      $scope.lcAmendApproveForm.LcAmendExpiryPlace = finalData[0].lcorder.lcExpiryPlace;
                      $scope.lcAmendApproveForm.AmendmentDetails = finalData[0].lcorder.lcAmendmentDetails;

                      const length = finalData[0].lcorder.amendData.length;
                      console.log("lenght",length);
                      $scope.lcAmendApproveForm.lcexpirydate = finalData[0].lcorder.amendData[length-1].lcAmendExpiryDate;
                      $scope.lcAmendApproveForm.lcexpiryplace = finalData[0].lcorder.amendData[length-1].lcAmendExpiryPlace;
                      $scope.lcAmendApproveForm.modeofshipment =  finalData[0].lcorder.amendData[length-1].amendModeOfShipment;
                      $scope.lcAmendApproveForm.lcamount =  finalData[0].lcorder.amendData[length-1].lcAmendAmount;

                      $scope.lcAmendApproveForm.lcId = finalData[0].lcorder.lcId;
                      $scope.lcAmendApproveForm.applicant = finalData[0].lcorder.applicantCustomer;
                      $scope.lcAmendApproveForm.applicantaddress = finalData[0].lcorder.applicantAddress;
                      $scope.lcAmendApproveForm.shipmentperiod =  finalData[0].lcorder.shipmentPeriod;
                      $scope.lcAmendApproveForm.beneficiary = finalData[0].lcorder.beneficiaryId;
                      $scope.lcAmendApproveForm.beneficiaryaddress = finalData[0].lcorder.beneficiaryAddress;
                      $scope.lcAmendApproveForm.lctype = finalData[0].lcorder.lcType;
                      $scope.lcAmendApproveForm.lccurrency = finalData[0].lcorder.lcCurrency;
                      $scope.lcAmendApproveForm.lcissuedate = finalData[0].lcorder.lcIssueDate;
                      $scope.lcAmendApproveForm.shipmentdate = finalData[0].lcorder.latestShipmentDate;
                      $scope.lcAmendApproveForm.liabilitydate = finalData[0].lcorder.liabilityReversalDate;
                      $scope.lcAmendApproveForm.beneficiarybank = finalData[0].lcorder.advisingBankID;
                      $scope.lcAmendApproveForm.applicantBank = finalData[0].lcorder.applicantBank;
                      $scope.lcAmendApproveForm.applicantBankAddress = finalData[0].lcorder.applicantBankAddress;
                      $scope.lcAmendApproveForm.beneficiarybankaddress = finalData[0].lcorder.advisingBankAddress;
                      $scope.lcAmendApproveForm.DocumentaryCredit = finalData[0].lcorder.formofDocumentaryCredit;
                      $scope.lcAmendApproveForm.CreditNumber = finalData[0].lcorder.documentaryCreditNumber;
                      $scope.lcAmendApproveForm.AvailableWith = finalData[0].lcorder.availableWithBy;
                      $scope.lcAmendApproveForm.TransportationTo = finalData[0].lcorder.forTransportationTo;
                      $scope.lcAmendApproveForm.DescOfGoods = finalData[0].lcorder.descriptionOfGoodsAndOrServices;
                      $scope.lcAmendApproveForm.additionalConditions = finalData[0].lcorder.additionalConditions;
                      $scope.lcAmendApproveForm.PeriodForPresentaion = finalData[0].lcorder.periodForPresentation;
                      $scope.lcAmendApproveForm.AdvisingThroughBank = finalData[0].lcorder.advisingThroughBank;
                      $scope.lcAmendApproveForm.transhipment = finalData[0].lcorder.transshipment;
                      $scope.lcAmendApproveForm.PortofLoading = finalData[0].lcorder.portofLoading;
                      $scope.lcAmendApproveForm.MaxCreditAmount = finalData[0].lcorder.maximumCreditAmount;
                      $scope.lcAmendApproveForm.DraftsAt = finalData[0].lcorder.draftsAt;
                      $scope.lcAmendApproveForm.PartialShipments = finalData[0].lcorder.partialShipments;
                      $scope.lcAmendApproveForm.SenderToReceiverInfo = finalData[0].lcorder.senderToReceiverInformation;
                      $scope.lcAmendApproveForm.Charges = finalData[0].lcorder.charges;
                      $scope.lcAmendApproveForm.ConfirmationInstruction = finalData[0].lcorder.confirmationInstructions;
                      $scope.lcAmendApproveForm.SequenceTotal = finalData[0].lcorder.sequenceOfTotal;
                      $scope.lcAmendApproveForm.DocRequired = finalData[0].lcorder.documentsRequired;
                      $scope.lcAmendApproveForm.iban = finalData[0].lcorder.ibanNumber;
                      $scope.lcAmendApproveForm.incoTerms=finalData[0].lcorder.incoTerms;
                        //New Changes:24-03-2017 : Deepak:Begin
                         $scope.lcAmendApproveForm.DraftsAt_sight=	finalData[0].lcorder.draftsAtSight;
                         $scope.lcAmendApproveForm.DraftsAt_usance=	finalData[0].lcorder.draftsAtUsance;
                         $scope.lcAmendApproveForm.shipmentperiod_sight=	finalData[0].lcorder.shipmentPeriodSight;
                         $scope.lcAmendApproveForm.shipmentperiod_usance=	finalData[0].lcorder.shipmentPeriodUsance;
                         $scope.lcAmendApproveForm.Percentage_sight=finalData[0].lcorder.percentageSight;
                         $scope.lcAmendApproveForm.Percentage_usance=	finalData[0].lcorder.percentageUsance;
                         $scope.lcAmendApproveForm.lcamount_sight=	finalData[0].lcorder.lcAmountSight;
                         $scope.lcAmendApproveForm.lcamount_usance=	finalData[0].lcorder.lcAmountUsance;

                      //New Changes:24-03-2017 : Deepak:END
                        });



                    $scope.amendApproveLC = () => {
                    const amendApproveLOC = {
                          lcId : $scope.lcAmendApproveForm.lcId,
                          lcReqId : $scope.lcRequestID,
                          //lcReqId : $scope.lcAmendApproveForm.LcAmendReqId,
                          applicantCustomer : $scope.lcAmendApproveForm.applicant,
                          applicantAddress : $scope.lcAmendApproveForm.applicantaddress,
                          beneficiaryId : $scope.lcAmendApproveForm.beneficiary,
                          beneficiaryAddress : $scope.lcAmendApproveForm.beneficiaryaddress,
                          lcType : $scope.lcAmendApproveForm.lctype,
                          lcCurrency : $scope.lcAmendApproveForm.lccurrency,
                          lcIssueDate : $scope.lcAmendApproveForm.lcissuedate,
                          latestShipmentDate : $scope.lcAmendApproveForm.shipmentdate,
                          liabilityReversalDate : $scope.lcAmendApproveForm.liabilitydate,
                          applicantBank : $scope.lcAmendApproveForm.applicantBank,
                          applicantBankAddress : $scope.lcAmendApproveForm.applicantBankAddress,
                          advisingBankAddress : $scope.lcAmendApproveForm.beneficiarybankaddress,
                          formofDocumentaryCredit : $scope.lcAmendApproveForm.DocumentaryCredit,
                          documentaryCreditNumber : $scope.lcAmendApproveForm.CreditNumber,
                          availableWithBy : $scope.lcAmendApproveForm.AvailableWith,
                          forTransportationTo : $scope.lcAmendApproveForm.TransportationTo,
                          descriptionOfGoodsAndOrServices : $scope.lcAmendApproveForm.DescOfGoods,
                          additionalConditions : $scope.lcAmendApproveForm.additionalConditions,
                          periodForPresentation : $scope.lcAmendApproveForm.PeriodForPresentaion,
                          advisingThroughBank : $scope.lcAmendApproveForm.AdvisingThroughBank,
                          transshipment : $scope.lcAmendApproveForm.transhipment,
                          portofLoading : $scope.lcAmendApproveForm.PortofLoading,
                          maximumCreditAmount : $scope.lcAmendApproveForm.MaxCreditAmount,
                          draftsAt : $scope.lcAmendApproveForm.DraftsAt,
                          partialShipments : $scope.lcAmendApproveForm.PartialShipments,
                          senderToReceiverInformation : $scope.lcAmendApproveForm.SenderToReceiverInfo,
                          charges : $scope.lcAmendApproveForm.Charges,
                          confirmationInstructions : $scope.lcAmendApproveForm.ConfirmationInstruction,
                          sequenceOfTotal : $scope.lcAmendApproveForm.SequenceTotal,
                          ibanNumber : $scope.lcAmendApproveForm.iban,
                          incoTerms:$scope.lcAmendApproveForm.incoTerms,

                          documentsRequired: $scope.lcAmendApproveForm.DocRequired,

                          shipmentPeriod : $scope.lcAmendApproveForm.shipmentperiod,
                          lcExpiryDate : new Date($scope.lcAmendApproveForm.LcAmendExpiryDate).toLocaleDateString(),
                          modeOfShipment : $scope.lcAmendApproveForm.amendModeOfShipment,
                          lcAmount : $scope.lcAmendApproveForm.lcAmendAmount,
                          lcExpiryPlace :  $scope.lcAmendApproveForm.lcAmendExpiryPlace,
                          lcNumberOfAmendment : $rootScope.version,
                          lcAmendmentDetails : $scope.lcAmendApproveForm.AmendmentDetails,
                          /*lcAmountTemp : $scope.lcAmendApproveForm.lcAmendAmount,*/
                          advisingBankID : $scope.lcAmendApproveForm.beneficiarybank,
                          //New Changes:24-03-2017 : Deepak:Begin

                          draftsAtSight : $scope.lcAmendApproveForm.DraftsAt_sight,
                          draftsAtUsance: $scope.lcAmendApproveForm.DraftsAt_usance,
                          shipmentPeriodSight: $scope.lcAmendApproveForm.shipmentperiod_sight,
                          shipmentPeriodUsance:$scope.lcAmendApproveForm.shipmentperiod_usance,
                          percentageSight: $scope.lcAmendApproveForm.Percentage_sight,
                          percentageUsance: $scope.lcAmendApproveForm.Percentage_usance,
                          lcAmountSight:$scope.lcAmendApproveForm.lcamount_sight,
                          lcAmountUsance:$scope.lcAmendApproveForm.lcamount_usance,

                       //New Changes:24-03-2017 : Deepak:END

                          //status : "APPROVED"
                                };
                                    const approveLCEndpoint =
                                        apiBaseURL +"lc-amend-approve";

console.log("amendApprove LOC object  ",amendApproveLOC);
                                   $http.post(approveLCEndpoint, angular.toJson(amendApproveLOC)).then(
                                   function(result){
                                    // success callback
                                    console.log("INSIDE SUCCESS FUNCTION");
                                    $location.path("/employeeHome");
                                    displayMessage(result);
                                    }, 
                                    function(result){
                                    // failure callback
                                    console.log("INSIDE ERROR FUNCTION");
                                    displayMessage(result);
                                                                         }
                                        //(result) => displayMessage(result),
                                        //(result) => displayMessage(result)
                                    );
                                    // console.log("LC approved and the object is  ",approveLoc);
                                     //console.log("message status" , $scope.messageStatus);
                                     //$location.path("/home");
                        }
                        $scope.cancel = () => {
                              $location.path("/employeeHome");
                        }
                        displayMessage = (message) => {
                        console.log("message in display message--->",message);
                        $rootScope.messageStatus = message.status;
                                const modalInstanceTwo = $uibModal.open({
                                    templateUrl: 'messageContent.html',
                                    controller: 'messageCtrl',
                                    controllerAs: 'modalInstanceTwo',
                                    resolve: { message: () => message }
                                });

                                modalInstanceTwo.result.then(() => {}, () => {});
                            };

                        function invalidFormInput() {
                            const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                    //            || !modalInstance.form.deliveryDate
                    //            || !modalInstance.form.city
                    //            || !modalInstance.form.country;
                    //
                    //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                    //
                    //        const invalidItemFields = modalInstance.items
                    //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                    //            .reduce((prev, curr) => prev && curr);

                            return invalidNonItemFields;
                        }
                        }
                                                else{
                                                $location.path("/customer");
                                                }

                  });
//====================================================================================================================================================================================
//AMEND APPROVE CONTROLLER END HERE
//====================================================================================================================================================================================
