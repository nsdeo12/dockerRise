
//Amend start here
app.controller('amendApprovalController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore) {
  if($cookieStore.get('employee')){
                    $scope.message = 'Approve Amended Letter of Credits ';
                    $scope.node = $rootScope.thisNode;
                     $scope.username = $cookieStore.get('employee');
                     console.log("APPROVING ID ===>",$rootScope.ApproveID,"  node is ",$scope.node," username is ",$scope.username);
                     const LCReqNumb = $rootScope.ID;

                        $scope.logout = function(){
                        $cookieStore.remove('employee');
                        $location.path("/customer");
                            };
                        $scope.lcAmendApproveForm = {};
                        $scope.formError = false;

                    const LCApprovalId = $rootScope.ApproveID;
                    const apiBaseURL = $rootScope.apiBaseURL;
                    //const getObj = apiBaseURL + "lc-orders";
                    const cusID1 = $cookieStore.get('employee');
                    const getObj = apiBaseURL + "employee-amended-lc-orders/"+LCApprovalId;

                    $http.get(getObj).then(function(response){
                    var finalData = response.data;
                    console.log("RESPONSE DATA ", finalData);
                    console.log("RESPONSE DATA final", finalData[0].lcorder,finalData[0]);
                    $scope.lcRequestID = finalData[0].lcorder.lcReqId;

                      //amend details assign here
                      const length = finalData[0].amendData.length;
                      console.log("lenght",length);
                      const size = finalData.size;
                      console.log("size",size)
                      /*$scope.lcAmendApproveForm.LcAmendId = finalData[0].lcorder;
                      $scope.lcAmendApproveForm.LcAmendReqId = finalData[0].lcorder.lcReqId;
                      $scope.lcAmendApproveForm.LcAmendAmount = finalData[0].lcorder.;
                      $scope.lcAmendApproveForm.shipmentperiod =  finalData[0].lcorder.shipmentPeriod;
                      $scope.lcAmendApproveForm.lcexpirydate = finalData[0].lcorder.lcExpiryDate;
                      $scope.lcAmendApproveForm.modeofshipment =  finalData[0].lcorder.modeOfShipment;
                      $scope.lcAmendApproveForm.beneficiary = finalData[0].lcorder.beneficiaryId;*/


                      $scope.lcAmendApproveForm.lcId = finalData[0].lcorder.lcId;
                      $scope.lcAmendApproveForm.applicant = finalData[0].lcorder.applicantCustomer;
                      $scope.lcAmendApproveForm.applicantaddress = finalData[0].lcorder.applicantAddress;
                      $scope.lcAmendApproveForm.shipmentperiod =  finalData[0].lcorder.shipmentPeriod;
                      $scope.lcAmendApproveForm.lcexpirydate = finalData[0].lcorder.lcExpiryDate;
                      $scope.lcAmendApproveForm.modeofshipment =  finalData[0].lcorder.modeOfShipment;
                      $scope.lcAmendApproveForm.beneficiary = finalData[0].lcorder.beneficiaryId;
                      $scope.lcAmendApproveForm.beneficiaryaddress = finalData[0].lcorder.beneficiaryAddress;
                      $scope.lcAmendApproveForm.lctype = finalData[0].lcorder.lcType;
                      $scope.lcAmendApproveForm.lccurrency = finalData[0].lcorder.lcCurrency;
                      $scope.lcAmendApproveForm.lcamount =  finalData[0].lcorder.lcAmount;
                      $scope.lcAmendApproveForm.lcissuedate = finalData[0].lcorder.lcIssueDate;
                      $scope.lcAmendApproveForm.lcexpiryplace = finalData[0].lcorder.lcExpiryPlace;
                      $scope.lcAmendApproveForm.shipmentdate = finalData[0].lcorder.latestShipmentDate;
                      $scope.lcAmendApproveForm.liabilitydate = finalData[0].lcorder.liabilityReversalDate;
                      $scope.lcAmendApproveForm.beneficiarybank = finalData[0].lcorder.advisingBankID;
                      $scope.lcAmendApproveForm.applicantBank = finalData[0].lcorder.applicantBank;
                      $scope.lcAmendApproveForm.applicantBankAddress = finalData[0].lcorder.applicantBankAddress;
                      $scope.lcAmendApproveForm.beneficiarybankaddress = finalData[0].lcorder.advisingBankAddress;
                      $scope.lcAmendApproveForm.DocumentaryCredit = finalData[0].lcorder.formofDocumentaryCredit;
                      $scope.lcAmendApproveForm.CreditNumber = finalData[0].lcorder.documentaryCreditNumber;
                      $scope.lcAmendApproveForm.AvailableWith = finalData[0].lcorder.availableWithBy;
                      $scope.lcAmendApproveForm.TransportationTo = finalData[0].lcorder.forTransportationTo;
                      $scope.lcAmendApproveForm.DescOfGoods = finalData[0].lcorder.descriptionOfGoodsAndOrServices;
                      $scope.lcAmendApproveForm.additionalConditions = finalData[0].lcorder.additionalConditions;
                      $scope.lcAmendApproveForm.PeriodForPresentaion = finalData[0].lcorder.periodForPresentation;
                      $scope.lcAmendApproveForm.AdvisingThroughBank = finalData[0].lcorder.advisingThroughBank;
                      $scope.lcAmendApproveForm.transhipment = finalData[0].lcorder.transshipment;
                      $scope.lcAmendApproveForm.PortofLoading = finalData[0].lcorder.portofLoading;
                      $scope.lcAmendApproveForm.MaxCreditAmount = finalData[0].lcorder.maximumCreditAmount;
                      $scope.lcAmendApproveForm.DraftsAt = finalData[0].lcorder.draftsAt;
                      $scope.lcAmendApproveForm.PartialShipments = finalData[0].lcorder.partialShipments;
                      $scope.lcAmendApproveForm.SenderToReceiverInfo = finalData[0].lcorder.senderToReceiverInformation;
                      $scope.lcAmendApproveForm.Charges = finalData[0].lcorder.charges;
                      $scope.lcAmendApproveForm.ConfirmationInstruction = finalData[0].lcorder.confirmationInstructions;
                      $scope.lcAmendApproveForm.SequenceTotal = finalData[0].lcorder.sequenceOfTotal;
                      $scope.lcAmendApproveForm.DocRequired = finalData[0].lcorder.documentsRequired;
                      $scope.lcAmendApproveForm.iban = finalData[0].lcorder.ibanNumber;
                      $scope.lcAmendApproveForm.incoTerms=finalData[0].lcorder.incoTerms;
                        });


                    $scope.amendApproveLC = () => {
                    const amendApproveLOC = {
                          lcId : $scope.lcAmendApproveForm.lcId,
                          lcReqId : $scope.lcRequestID,
                          applicantCustomer : $scope.lcAmendApproveForm.applicant,
                          applicantAddress : $scope.lcAmendApproveForm.applicantaddress,
                          shipmentPeriod : $scope.lcAmendApproveForm.shipmentperiod,
                          lcExpiryDate : $scope.lcAmendApproveForm.lcexpirydate,
                          modeOfShipment : $scope.lcAmendApproveForm.modeofshipment,
                          beneficiaryId : $scope.lcAmendApproveForm.beneficiary,
                          beneficiaryAddress : $scope.lcAmendApproveForm.beneficiaryaddress,
                          lcType : $scope.lcAmendApproveForm.lctype,
                          lcCurrency : $scope.lcAmendApproveForm.lccurrency,
                          lcAmount : $scope.lcAmendApproveForm.lcamount,
                          lcIssueDate : $scope.lcAmendApproveForm.lcissuedate,
                          lcExpiryPlace : $scope.lcAmendApproveForm.lcexpiryplace,
                          latestShipmentDate : $scope.lcAmendApproveForm.shipmentdate,
                          liabilityReversalDate : $scope.lcAmendApproveForm.liabilitydate,
                          advisingBankID : $scope.lcAmendApproveForm.beneficiarybank,
                          applicantBank : $scope.lcAmendApproveForm.applicantBank,
                          applicantBankAddress : $scope.lcAmendApproveForm.applicantBankAddress,
                          advisingBankAddress : $scope.lcAmendApproveForm.beneficiarybankaddress,
                          formofDocumentaryCredit : $scope.lcAmendApproveForm.DocumentaryCredit,
                          documentaryCreditNumber : $scope.lcAmendApproveForm.CreditNumber,
                          availableWithBy : $scope.lcAmendApproveForm.AvailableWith,
                          forTransportationTo : $scope.lcAmendApproveForm.TransportationTo,
                          descriptionOfGoodsAndOrServices : $scope.lcAmendApproveForm.DescOfGoods,
                          additionalConditions : $scope.lcAmendApproveForm.additionalConditions,
                          periodForPresentation : $scope.lcAmendApproveForm.PeriodForPresentaion,
                          advisingThroughBank : $scope.lcAmendApproveForm.AdvisingThroughBank,
                          transshipment : $scope.lcAmendApproveForm.transhipment,
                          portofLoading : $scope.lcAmendApproveForm.PortofLoading,
                          maximumCreditAmount : $scope.lcAmendApproveForm.MaxCreditAmount,
                          draftsAt : $scope.lcAmendApproveForm.DraftsAt,
                          partialShipments : $scope.lcAmendApproveForm.PartialShipments,
                          senderToReceiverInformation : $scope.lcAmendApproveForm.SenderToReceiverInfo,
                          charges : $scope.lcAmendApproveForm.Charges,
                          confirmationInstructions : $scope.lcAmendApproveForm.ConfirmationInstruction,
                          sequenceOfTotal : $scope.lcAmendApproveForm.SequenceTotal,
                          ibanNumber : $scope.lcAmendApproveForm.iban,
                          incoTerms:$scope.lcAmendApproveForm.incoTerms,

                          documentsRequired: $scope.lcAmendApproveForm.DocRequired,
                                };
                                    const approveLCEndpoint =
                                        apiBaseURL +"lc-approve";

console.log("amendApprove LOC object  ",amendApproveLOC);
                                   $http.post(amendApproveLCEndpoint, angular.toJson(amendApproveLOC)).then(
                                   function(result){
                                    // success callback
                                    console.log("INSIDE SUCCESS FUNCTION");
                                    $location.path("/employeeHome");
                                    displayMessage(result);
                                    }, 
                                    function(result){
                                    // failure callback
                                    console.log("INSIDE ERROR FUNCTION");
                                    displayMessage(result);
                                                                         }
                                        //(result) => displayMessage(result),
                                        //(result) => displayMessage(result)
                                    );
                                    // console.log("LC approved and the object is  ",approveLoc);
                                     //console.log("message status" , $scope.messageStatus);
                                     //$location.path("/home");
                        }
                        $scope.cancel = () => {
                              $location.path("/employeeHome");
                        }
                        displayMessage = (message) => {
                        console.log("message in display message--->",message);
                        $rootScope.messageStatus = message.status;
                                const modalInstanceTwo = $uibModal.open({
                                    templateUrl: 'messageContent.html',
                                    controller: 'messageCtrl',
                                    controllerAs: 'modalInstanceTwo',
                                    resolve: { message: () => message }
                                });

                                modalInstanceTwo.result.then(() => {}, () => {});
                            };

                        function invalidFormInput() {
                            const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                    //            || !modalInstance.form.deliveryDate
                    //            || !modalInstance.form.city
                    //            || !modalInstance.form.country;
                    //
                    //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                    //
                    //        const invalidItemFields = modalInstance.items
                    //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                    //            .reduce((prev, curr) => prev && curr);

                            return invalidNonItemFields;
                        }
                        }
                                                else{
                                                $location.path("/customer");
                                                }

                  });
