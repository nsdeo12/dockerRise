app.factory('shareid',function(){
  return {ID:''};
  return{lcIDnew:''};
  return{lcApproveID:''};
  return {thisNode:''};
});
 app.controller('employeeHomeController', function($scope,$rootScope,$http,$location,$cookies, $cookieStore,rootValues,shareid) {
         if($cookieStore.get('employee')){

           console.log("rootValues in employee",rootValues.data1);
                  $scope.message = 'Letter of Credit';
                  $scope.username = $cookieStore.get('employee');

                     $scope.tab = 1;
                     $scope.setTab = function(newTab){
                     $scope.tab = newTab;
                      };
                     $scope.logout = function(){
                            $cookieStore.remove('employee');
                            $location.path("/customer");
                          };

                           $scope.Documents = function(ID){

                                                $rootScope.LCID = ID;
                                               console.log("ID in home page  ",ID);
                                                $location.path("/Documents");
                                                         }
                      $scope.isSet = function(tabNum){
                      return $scope.tab === tabNum;
                      };

                      const nodePort = $location.port();
                      const apiBaseURL = "http://"+window.__env.apiUrl+":" + nodePort + "";
                     // $rootScope.apiBaseURL = apiBaseURL;
					 
					 $http.get(apiBaseURL + "/lcRequestID").then(function(response){                
					shareid.lcIDnew =response.data;
					console.log("lcIDnew",shareid.lcIDnew);
					})
					
					 
					 
					 

                      $scope.getLCs = () => $http.get(apiBaseURL + "/lcreq")
                                    .then((response) => $scope.loc = Object.keys(response.data)
                                    .map((key) => response.data[key])
                                    .reverse());
                      $scope.getLCs();
                      ///Display default data for employee view
                      					  //Start
                      					  $scope.locempDefaultdata = (locobj) =>{

                      							var defaultdata   = locobj;
                      						 $scope.amendAmountval				= defaultdata.lcAmount;
                                               $scope.lcAmendAdvisingBankRefval   = defaultdata.advisingBankID;
                                               $scope.amendModeOfShipmentval	    = defaultdata.modeOfShipment;
                                               $scope.lcAmendExpiryDateval	    = defaultdata.lcExpiryDate;
                                               $scope.lcAmendExpiryPlaceval		= defaultdata.lcExpiryPlace;

                      						}

                      					$scope.bgempDefaultdata = (bgobj) =>{

                      							var bgdefaultdata 		 = bgobj;
                      				  $scope.bgamendAmountval    = bgdefaultdata.principalAmount;
                                       $scope.bgAmendExpiryDateval = bgdefaultdata.expiryDate;
                                       $scope.bgTermsAndConditions = bgdefaultdata.termsAndConditions;

                      					}
                      					//End
                    /*  $scope.getProcessedLCs = () => $http.get(apiBaseURL + "/lc-orders")
                                 .then((response) => $scope.loc1 = Object.keys(response.data)
                                 .map((key) => response.data[key].state.data)
                                 .reverse());
                      $scope.getProcessedLCs();*/
					  
					  $http.get(apiBaseURL + "/lc-orders").then(function(response){
                  console.log("RESPONSE OF LC ORDERS===>",response);
                   $scope.loc1 = response.data;
                   console.log("LC-ORDERS===>",response.data[0]);
                        });

                      $scope.openLc = (ID) => {
                            $location.path("/lcOpen");
                        shareid.ID=ID;
                      $scope.ID=shareid.ID;
                        // $rootScope.ID = $scope.ID;
                        console.log("ID in home page  ",$scope.ID);
                         }


////////////////////////////////open BG starts//////////////
                     $scope.getBGs = () => $http.get(apiBaseURL + "/bg-req-empname/"+$scope.username)
                                                .then((response) => $scope.openbgs = Object.keys(response.data)
                                                .map((key) => response.data[key])
                                                .reverse());

                    //$rootScope.bgRequestID = response.data.bgID;


//                    $scope.getBGs1 = () => $http.get(apiBaseURL + "bg-req-empname/"+$scope.username)
//                             .then(function(response){
//                             $scope.bgs1 = response.data;
//                             console.log("BGS OBJECT  ",$scope.bgs1);
//                             });
                    $scope.getBGs();
                    const v1=$scope.getBGs();
                    console.log("openbgs set 3 ",v1);

//                    $scope.getBGsFromCorda = () => $http.get(apiBaseURL + "bg-orders")
//                             .then(function(response){
//                             $scope.cordaAllBG = response.data;
//                             console.log("BGS corda all OBJECT  ",$scope.cordaAllBG);
//                             });
//
                      $scope.getBGsFromCorda = () => $http.get(apiBaseURL + "/bg-orders")
                                 .then((response) => $scope.cordaAllBG = Object.keys(response.data)
                                 .map((key) => response.data[key].state.data)
                                 .reverse());

                    $scope.getBGsFromCorda();

                      const v=$scope.getBGs();
                      console.log("val bg",v);
                      console.log("test",$scope.getBGs1);

                     $scope.openBG = (bgOpenID) => {
                                         $rootScope.bgOpenID = bgOpenID;
                                         $location.path("/bgOpen");
                                     console.log("ID in BgOpen  ",bgOpenID);
                                              }

                      $scope.approveBG = (bgApproveID) => {
                                          $location.path("/bgApprove");
                                      $rootScope.bgApproveID = bgApproveID;
                                      console.log("ID in BG approve  ",bgApproveID);
                                               }


 $scope.approveAmendedBG = (bgApproveAmendID) => {
                                 $location.path("/bgApproveAmend");
                             $rootScope.bgApproveAmendID = bgApproveAmendID;
                             console.log("ID in BG approve  ",bgApproveAmendID);
                                      }




$scope.disableBGApproveBn=(bog)=>{
console.log("bog  here:scope.node",$rootScope.thisNode);
if(bog.bgorder.beneficiaryBank != $rootScope.thisNode || bog.status == "BG APPROVED" || bog.status == "BG AMEND APPROVED"){
       return true;
    }
    else if(bog.status == "BG AMENDED"){
       return true;
    }
    else{
        return false;
    }
}

////////////////////////////////open BG ends//////////////

                    //start
                    $scope.getAmendedLCs = () => $http.get(apiBaseURL + "/lcamendreq")
                                    .then((response) => $scope.locamend = Object.keys(response.data)
                                    .map((key) => response.data[key])
                                    .reverse());
                    $scope.getAmendedLCs();

                    //end

                    $scope.getAmendedBGs = () => $http.get(apiBaseURL + "/bg-amend-req")
                                                            .then((response) => $scope.bogamend = Object.keys(response.data)
                                                            .map((key) => response.data[key])
                                                            .reverse());
                                              $scope.getAmendedBGs();

                    //start here
                    $scope.amendAccept = (AmendID,AmendReqID) => {
                            $rootScope.AmendID = AmendID;
                            $rootScope.AmendReqID = AmendReqID;
                            console.log("AmendID in home page  ",AmendID,AmendReqID);
                            $location.path("/lcAmendAccept");
                    }
                    $scope.BGamendAccept = (bgAmendID,bgAmendReqID) => {
                                                $rootScope.bgAmendID = bgAmendID;
                                                $rootScope.bgAmendReqID = bgAmendReqID;
                                                console.log("AmendID in home page  ",bgAmendID,bgAmendReqID);
                                                $location.path("/bgAcceptAmend");
                                        }

                    //end here

                    //start here
                    $scope.approveAmendedLC = (AmendID) => {
                             $rootScope.AmendID = AmendID;
                             //$rootScope.AmendReqID = AmendReqID;
                             console.log("AmendID in home page  ",AmendID);
                             $location.path("/lcAmendApprove");
                    }
                    //end here


                  $scope.approveLc = (ApproveID) => {
                  $location.path("/lcApprove");
				  shareid.lcApproveID=ApproveID;
                  //$rootScope.ApproveID = ApproveID;
                  console.log("lcApproveID in employee page  ",shareid.lcApproveID,ApproveID);
                          }

                   $http.get(apiBaseURL + "/lcRequestID").then(function(response){
					   $rootScope.temp=response.data;
					   console.log('temp',$rootScope.temp);
                   $scope.lcRequestID = response.data;
                    console.log("lcID in customer home page===>",response.data);
                               });

                 $scope.getMyLegalName = () => $http.get(apiBaseURL + "/me").then(function(response){
                   $scope.thisNode = response.data;
				   shareid.thisNode = $scope.thisNode;
                   //$scope.thisNode = $scope.thisNode;
                   console.log("me===>",response.data);
                        });
                    $scope.getMyLegalName();


//================================================================================================================================
// Below is the logic for displaying the amended lc records based on the version number
//================================================================================================================================

//Start

$scope.numberofamendval = null;

$scope.empamendList=function(id,amendId){

$scope.numberofamendval = id
                                const getObj = apiBaseURL + "/employee-lc-orders/"+amendId;
                                  $http.get(getObj).then(function(response){

                                          var finalData = response.data;
                                          var len=finalData[0].lcorder.lcNumberOfAmendment;

                                          var idVal= parseInt(id);
                                          console.log("length",len);
                                          console.log("idVal",idVal);



                            if (idVal==len){

                                          $scope.amendAmountval=finalData[0].lcorder.lcAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.lcNumberOfAmendment;
                                          $scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.advisingBankID;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.modeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.lcExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.lcExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.lcAmendmentDetails;

                                            console.log("id last:",idVal,"length",len)
                                          }

                                          else
                                           {
                                          $scope.amendAmountval=finalData[0].lcorder.amendData[idVal].lcAmendAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.amendData[idVal].numberOfAmendment;
                                          $scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.amendData[idVal].lcAmendAdvisingBankRef;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.amendData[idVal].amendModeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.amendData[idVal].amendmentDetails;
                                            console.log("id others:",idVal,"length",len)
                                          }


                                          });
                              }


    $scope.empmyvar = false;

    $scope.historyemp=(amendId)=>{

    $scope.empmyvar = true;

    const getObj = apiBaseURL + "/employee-lc-orders/"+amendId;

         $http.get(getObj).then(function(response){

                                           var finalData = response.data;
                                          var len=finalData[0].lcorder.lcNumberOfAmendment;

    if($scope.numberofamendval!=null){
                                          var idVal= parseInt($scope.numberofamendval);
                                          console.log("length",len);
                                          console.log("idVal",idVal);



                            if (idVal==len){

                                          $scope.amendAmountval=finalData[0].lcorder.lcAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.lcNumberOfAmendment;
                                          //$scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.advisingBankID;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.modeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.lcExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.lcExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.lcAmendmentDetails;

                                            console.log("id last:",idVal,"length",len)
                                          }

                                          else
                                           {
                                          $scope.amendAmountval=finalData[0].lcorder.amendData[idVal].lcAmendAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.amendData[idVal].numberOfAmendment;
                                          //$scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.amendData[idVal].lcAmendAdvisingBankRef;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.amendData[idVal].amendModeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.amendData[idVal].amendmentDetails;
                                            console.log("id others:",idVal,"length",len)
                                          }
}

                                          });

        }

        /////////////history of amend BG/////

        $scope.bgnumberofamendval = null;
        $scope.empamendBGList=function(id,amendId){

        console.log("bg amendid ===>",amendId);
        console.log("bg no.of amend ===>",id);

        $scope.bgnumberofamendval = id
                                        const getObj = apiBaseURL + "/employee-bg-orders/"+amendId;
                                          $http.get(getObj).then(function(response){

                                                  var finalData = response.data;
                                                  var len=finalData[0].bgorder.bgMainNumberOfAmendment;

                                                  var idVal= parseInt(id);
                                                  console.log("length",len);
                                                  console.log("idVal",idVal);



                                    if (idVal==len){

                                                  $scope.bgamendAmountval=finalData[0].bgorder.principalAmount;

                                                  $scope.bgAmendExpiryDateval=finalData[0].bgorder.expiryDate;
                                                  $scope.bgTermsAndConditions =finalData[0].bgorder.termsAndConditions;


                                                    console.log("id last:",idVal,"length",len)
                                                  }

                                                  else
                                                       {

                                                      $scope.bgamendAmountval=finalData[0].bgorder.bgAmendData[idVal].bgAmendPrincipalAmount;

                                                      $scope.bgAmendExpiryDateval=finalData[0].bgorder.bgAmendData[idVal].bgExpiryDate;
                                                      $scope.bgTermsAndConditions =finalData[0].bgorder.bgAmendData[idVal].bgTermsAndConditions;
                                                         }


                                                  });
                                      }

        //History method


            $scope.empbgmyvar = false;

              $scope.bghistoryemp=(amendId)=>{

              $scope.empbgmyvar = true;

              const getObj = apiBaseURL + "/employee-bg-orders/"+amendId;

                   $http.get(getObj).then(function(response){

                                                     var finalData = response.data;
                                                    var len=finalData[0].bgorder.bgMainNumberOfAmendment;

              if($scope.bgnumberofamendval!=null){
                                                    var idVal= parseInt($scope.bgnumberofamendval);
                                                    console.log("length",len);
                                                    console.log("idVal",idVal);


                                      if (idVal==len){

                                                $scope.bgamendAmountval=finalData[0].bgorder.principalAmount;

                                                 $scope.bgAmendExpiryDateval=finalData[0].bgorder.expiryDate;
                                                 $scope.bgTermsAndConditions =finalData[0].bgorder.termsAndConditions;
              console.log("finalData[0].bgorder if case",finalData[0],"gap",finalData[0].bgorder);

                                                    }

                                                    else
                                                     {
                                                     console.log("finalData[0].bgorder.bgAmendData[idVal-1].principalAmount",finalData[0],"gap",finalData[0].bgorder.bgAmendData[idVal]);
                                                 $scope.bgamendAmountval=finalData[0].bgorder.bgAmendData[idVal].bgAmendPrincipalAmount;

                                                 $scope.bgAmendExpiryDateval=finalData[0].bgorder.bgAmendData[idVal].bgExpiryDate;
                                                 $scope.bgTermsAndConditions =finalData[0].bgorder.bgAmendData[idVal].bgTermsAndConditions;
                                                    }
          }

                                                    });

                  }





        ////////END////////////////////////////

         // End

        //disable part start here

$scope.disableButton=(loc)=>{
console.log("before====>",loc.advisingBankID,$scope.thisNode)
//|| loc.status == "APPROVED" || loc.status == "AMEND_APPROVED"
    if(loc.advisingBankID != $scope.thisNode){
		console.log("DAAATAAA====>",loc.advisingBankID,$scope.thisNode)
       return true;
    }
    else if(loc.status == "AMENDED"  || loc.status == "APPROVED" || loc.status == "AMEND APPROVED"){
       return true;
    }
    else{
        return false;
    }

}
$scope.disableAmendButton=(loc)=>{

                               //|| loc.status == "APPROVED" || loc.status == "AMEND_APPROVED"
               /*       if(loc.lcorder.advisingBankID != $rootScope.thisNode || loc.status == "APPROVED" || loc.status == "AMEND APPROVED"){
                         return true;
                      }
                      else if(loc.status == "OPENED"){
                         return true;
                      }
                      else{
                          return false;
                      }
*/
                  }

$scope.disableBgAmendButton=(bog)=>{

console.log("hi came here:bog",bog);
console.log("hi came here:scope.node",$rootScope.thisNode);
//|| loc.status == "APPROVED" || loc.status == "AMEND_APPROVED"
    if(bog.bgorder.beneficiaryBank != $rootScope.thisNode || bog.status == "BG APPROVED" || bog.status == "BG AMEND APPROVED"){
       return true;
    }
    else if(bog.status == "BG OPENED"){
       return true;
    }
    else{
        return false;
    }

}
//end here



                        }
                        else{
                        $location.path("/customer");
                        }
                });
