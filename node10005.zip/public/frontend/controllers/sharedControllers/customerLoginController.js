app.controller('customerLoginController', function($scope ,$rootScope,$http,$location,$cookies, $cookieStore) {
$scope.message = 'Customer login form';
			const nodePort = $location.port();
			const apiBaseURL = "http://"+window.__env.apiUrl+":" + nodePort + "";
			$rootScope.apiBaseURL = apiBaseURL;
			console.log("apiBaseURL===>",apiBaseURL);
			$scope.userLogin = () =>{
                const emailid = $scope.emailid;

    $http.get(apiBaseURL + "/customer/" + emailid).then( function(response){
                                                                                                                                 // success callback
     console.log("INSIDE SUCCESS FUNCTION");
     const username = response.data;
           console.log("username of customer===>",response.data[0].name);
           $cookieStore.put('customer', response.data[0].name);
           $location.path("/customerHome");
       },
        function(response){
           $scope.errorMsg="Invalid Email / Password"
          console.log("INSIDE ERROR FUNCTION");

          })
                  }
 });
