app.service('rootValues', function() {
var data1={};
this.save=function(data1){
  this.data1=data1;
}
this.getData1=function(){
  return data1;
}

  var _Id = {

    name: "test",
    surname: "doe",
    node:"192.168.22.1",

    id:""
  }

  return {
    id: _Id

  }
});


app.controller('customerHomeController', function($scope,$rootScope,$http,$location,$cookies, $cookieStore,$anchorScroll,rootValues) {
     if($cookieStore.get('customer')){
          $scope.message = 'Letter of Credit';
          $scope.username = $cookieStore.get('customer');
          const nodePort = $location.port();
          const apiBaseURL = "http://"+window.__env.apiUrl+":" + nodePort + "";
          $rootScope.apiBaseURL = apiBaseURL;
             $scope.tab = 0;
             $scope.setTab = function(newTab){
             $scope.tab = newTab;
              };


              $scope.isSet = function(tabNum){
              return $scope.tab === tabNum;
              };


              $http.get(apiBaseURL + "/lcRequestID").then(function(response){
                console.log("asdas",response);
                // rootValues.id =response.data;
                rootValues.data1 =response.data;
               console.log("$scope.id",rootValues.data1);
             })


           /*==========================================================================================================================
                               ****************Code for LC Amendment Request************************
                               ****************Developer name : Kesavan N B
                                *****************Start************************/

            /*$scope.amendLc = (AmendID) => {
                $location.path("/lcAmend");
                $rootScope.AmendID = AmendID;
                console.log("ID in home page  ",AmendID);
                        };*/

                         $scope.amendLc = (AmendID) => {

                                                      $rootScope.AmendID = AmendID;
                                                      console.log("lcid",AmendID);
                                                       $http.get(apiBaseURL + "/lc-amend-req/"+AmendID).then( function(response){
                                                       console.log("INSIDE SUCCESS FUNCTION");
                                                       const StatusFromDB = response.data;
                                                       const statusvalue = response.data.status;
                                                       console.log("status from api===>",StatusFromDB );


                                                       //if(response.data.status = 'AmendRequested')
                                                      if(statusvalue == 'AmendRequested')

                                                    {
                                                    console.log("response.data.status",response.data.status);
                                                    console.log("inside status if");
                                                    //return false;
                                                    alert("LC Amend Request is in progress");
                                                    $location.path("/customerHome");
                                                    //alert("hi");
                                                    /*$scope.status = function(){

                                                    return false;
                                                    }*/
                                                    }
                                                    else{
                                                    console.log("inside status else");
                                                    $location.path("/lcAmend");
                                                    //return true;

                                                    }
                                                 });
                               };


                        //-------------------------------------------------------End----------------------------------------------------------------------------------
				//bg amend start

$scope.amendBG = (AmendID) => {
                $rootScope.BgAmendID = AmendID;
                          console.log("bgid",AmendID);
                $http.get(apiBaseURL + "/getbg-amend-req/"+AmendID).then( function(response){
                           console.log("INSIDE SUCCESS FUNCTION");
                           const StatusFromDB = response.data;
                           const statusvalue = response.data.bgstatus;
                           console.log("status from api===>",StatusFromDB );


                           //if(response.data.status = 'AmendRequested')
                   if(statusvalue == 'AMEND REQUESTED')
                       {
                        console.log("response.data.status",response.data.status);
                        console.log("inside status if");
                        //return false;
                        alert("BG Amend Request is in progress");
                        $location.path("/customerHome");
                        //alert("hi");
                        /*$scope.status = function(){

                        return false;
                        }*/
                       }
                   else{
                        console.log("inside status else");
                        $location.path("/bgAmend");
                        //return true;

                        }
                });

                         };

//end

//-------------------------------------------------------End----------------------------------------------------------------------------------
              $scope.logout = function(){
                    $cookieStore.remove('customer');
                    $location.path("/customer");
                    var cust= $cookieStore.get('customer');
                    console.log("customer  ",cust);
                              };

              $scope.getLCs = () => $http.get(apiBaseURL + "/get-customer-lc/"+$scope.username)
                            .then((response) => $scope.loc = Object.keys(response.data)
                            .map((key) => response.data[key])
                            .reverse());
              $scope.getLCs();

              //Logic for displaying default data
              //Start

              $scope.loccusDefaultdata = (locobj) =>{

              		var defaultdata 			  = locobj;
                      $scope.amendAmountval		  = defaultdata.lcAmount;
                      $scope.amendModeOfShipmentval = defaultdata.modeOfShipment;
                      $scope.lcAmendExpiryDateval   = defaultdata.lcExpiryDate;
              	    $scope.lcAmendExpiryPlaceval  = defaultdata.lcExpiryPlace;

              }

              $scope.bgcusDefaultdata = (bgobj) =>{

              		var bgdefaultdata 		 = bgobj;
                   $scope.bgamendAmountval	 = bgdefaultdata.principalAmount;
                   $scope.bgAmendExpiryDateval = bgdefaultdata.expiryDate;
                   $scope.bgTermsAndConditions = bgdefaultdata.termsAndConditions;

              }
              //End

//////////////////////////////////////////////////////start getting bg list of customer///////////////////////////////////////////////////////////////////
             $scope.getBGs = () => $http.get(apiBaseURL + "/bg-req-custname/"+$scope.username)
                            .then((response) => $scope.bgs = Object.keys(response.data)
                            .map((key) => response.data[key])
                            .reverse());
                $scope.getBGs1 = () => $http.get(apiBaseURL + "/bg-req-custname/"+$scope.username)
                         .then(function(response){
                         $scope.bgs1 = response.data;
                         console.log("BGS OBJECT  ",$scope.bgs1);
                         });
                         $scope.getBGs();

              const v=$scope.getBGs();
              console.log("val bg",v);
              console.log("test",$scope.getBGs1);


              $scope.getProcessedBGs = () => $http.get(apiBaseURL + "/customer-bg-orders/" +$scope.username)
                                       .then((response) => $scope.bog1 = Object.keys(response.data)
                                       .map((key) => response.data[key])
                                       .reverse());
                            $scope.getProcessedBGs();



//////////////////////////////////////////////////////end getting bg list of customer///////////////////////////////////////////////////////////////////

              //start
                            $scope.getAmendedLCs = () => $http.get(apiBaseURL + "/lcamendreq")
                                          .then((response) => $scope.locamend = Object.keys(response.data)
                                          .map((key) => response.data[key])
                                          .reverse());
                            $scope.getAmendedLCs();
              //end

              $scope.getAmendedBGs = () => $http.get(apiBaseURL + "/bg-amend-req")
                                        .then((response) => $scope.bogamend = Object.keys(response.data)
                                        .map((key) => response.data[key])
                                        .reverse());
                          $scope.getAmendedBGs();
						  
			$http.get(apiBaseURL + "/lc-orders").then(function(response){
                  console.log("RESPONSE OF LC ORDERS===>",response);
                   $scope.loc1 = response.data;
                   console.log("LC-ORDERS===>",response.data[0]);
                        });

              /*
			  $scope.getProcessedLCs = () => $http.get(apiBaseURL + "/customer-lc-orders/" +$scope.username)
                         .then((response) => $scope.loc1 = Object.keys(response.data)
                         .map((key) => response.data[key])
                         .reverse());
              $scope.getProcessedLCs();*/

              $http.get(apiBaseURL + "/me").then(function(response){
                              $scope.thisNode = response.data;

							 //$rootScope.thisNode=response.data;

                              console.log("me===>",response.data);

                                       });
//////////////////////////////////////////////for email sending begins//////////////////////////////////////
              $http.get(apiBaseURL + "/lcRequestID").then(function(response){

                console.log("lcRequestID===>",response.data);
				$rootScope.lcRequestID = response.data.lcRequestID;



//                $scope.showHide=()=>{

                    /////hide the modal starts///////////////////////
                            $scope.IsHidden = true;
                            $scope.emailForm={};
                            $scope.getMail = (iban) => {

                                    console.log("hidden now");

                      /////////////applicant mail id starts//////////
                                    $scope.username = $cookieStore.get('customer');
                                    $http.get($rootScope.apiBaseURL + "/customer/detail/id/"+ $scope.username).then(function(response){
                                    const fromEmail=response.data.email;
                                    console.log("from Mail:",fromEmail);
                                    $scope.emailForm.fromEmail=fromEmail;

                                    });
                      /////////////applicant mail id ends//////////
                      /////////////beneficiary mail id starts//////
                            $rootScope.iban = iban;
                            $http.get($rootScope.apiBaseURL + "/customer/detail/"+ iban).then(function(response){
                            const toMail=response.data.email;
                            console.log("beneficiary Obj: ",$rootScope.apiBaseURL + "/customer/detail/"+ iban);
                            console.log("tomail: ",toMail,toMail);
                            $scope.emailForm.toEmail=toMail;

                            });
                      /////////////beneficiary mail id ends//////
                        }
                            $scope.showHide = function () {
                            console.log("inhidden!:)")
                      //If DIV is hidden it will be visible and vice versa.
                                $scope.IsHidden = $scope.IsHidden ? false : true;
                            }
                            $scope.send=function(){

                            console.log("testS",$scope.emailForm.subject,$scope.emailForm.mailbody);
                                    const email={
                                        from:$scope.emailForm.fromEmail,
                                        to:$scope.emailForm.toEmail,
                                        subject:$scope.emailForm.subject,
                                        msg:$scope.emailForm.mailbody
                                        };
                                        console.log("email Obj",angular.toJson(email));
                                        const emailCreate =apiBaseURL +"/email-for-amend";
                                        $http.post(emailCreate, angular.toJson(email)).then(function(result){
                                        console.log("success",angular.toJson(email));
                                        });
                            $scope.IsHidden=true;
                            }
                             $scope.cancel = () => {
                             $scope.IsHidden=true;
                                     $location.path("/customerHome");
                                            }
                                console.log("lcRequestID in customer home page===>",rootValues.data1);
                                             });
///////////////////////////////////////////////for email sending ends//////////////////////////////////////

//for versions and history/////////////////////
// $scope.getLength = () => $http.get(apiBaseURL + "customer-lc-orders/"+$scope.username)
//                            .then(function(response){
//                            var finalData = response.data;
//                            console.log("length in func "+ finalData);
//                        $scope.versionLength = finalData[0].lcorder.amendData.length;
//                        console.log("domg ",finalData[0].lcorder.amendData.length);
//                            });
//              $scope.getLength();
//

//================================================================================================================================
// Below is the logic for displaying the amended lc records based on the version number
//================================================================================================================================

//Start

$scope.numberofamendval = null;

$scope.amendList=function(id,amendId){

$scope.numberofamendval = id
                                const getObj = apiBaseURL + "/employee-lc-orders/"+amendId;
                                  $http.get(getObj).then(function(response){

                                          var finalData = response.data;
                                          var len=finalData[0].lcorder.lcNumberOfAmendment;

                                          var idVal= parseInt(id);
                                          console.log("length",len);
                                          console.log("idVal",idVal);



                            if (idVal==len){

                                          $scope.amendAmountval=finalData[0].lcorder.lcAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.lcNumberOfAmendment;
                                          //$scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.advisingBankID;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.modeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.lcExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.lcExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.lcAmendmentDetails;

                                            console.log("id last:",idVal,"length",len)
                                          }

                                          else
                                           {
                                          $scope.amendAmountval=finalData[0].lcorder.amendData[idVal].lcAmendAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.amendData[idVal].numberOfAmendment;
                                          //$scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.amendData[idVal].lcAmendAdvisingBankRef;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.amendData[idVal].amendModeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.amendData[idVal].amendmentDetails;
                                            console.log("id others:",idVal,"length",len)
                                          }


                                          });
                              }


    $scope.myvar = false;

    $scope.historycus=(amendId)=>{

    $scope.myvar = true;

    const getObj = apiBaseURL + "/employee-lc-orders/"+amendId;

         $http.get(getObj).then(function(response){

                                           var finalData = response.data;
                                          var len=finalData[0].lcorder.lcNumberOfAmendment;

    if($scope.numberofamendval!=null){
                                          var idVal= parseInt($scope.numberofamendval);
                                          console.log("length",len);
                                          console.log("idVal",idVal);


                            if (idVal==len){

                                          $scope.amendAmountval=finalData[0].lcorder.lcAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.lcNumberOfAmendment;
                                          $scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.advisingBankID;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.modeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.lcExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.lcExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.lcAmendmentDetails;

                                            console.log("id last:",idVal,"length",len)
                                          }

                                          else
                                           {
                                          $scope.amendAmountval=finalData[0].lcorder.amendData[idVal].lcAmendAmount;
                                          //$scope.numberOfAmendmentval=finalData[0].lcorder.amendData[idVal].numberOfAmendment;
                                          $scope.lcAmendAdvisingBankRefval=finalData[0].lcorder.amendData[idVal].lcAmendAdvisingBankRef;
                                          $scope.amendModeOfShipmentval=finalData[0].lcorder.amendData[idVal].amendModeOfShipment;
                                          $scope.lcAmendExpiryDateval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryDate;
                                          $scope.lcAmendExpiryPlaceval=finalData[0].lcorder.amendData[idVal].lcAmendExpiryPlace;
                                          //$scope.amendmentDetailsval=finalData[0].lcorder.amendData[idVal].amendmentDetails;
                                            console.log("id others:",idVal,"length",len)
                                          }
}

                                          });

        }

/////////////////////////BG amend history/////////////////
//START


$scope.amendBGList=function(id,amendId){

console.log("bg amendid ===>",amendId);
console.log("bg no.of amend ===>",id);

$scope.bgnumberofamendval = id
                                const getObj = apiBaseURL + "/employee-bg-orders/"+amendId;
                                  $http.get(getObj).then(function(response){

                                          var finalData = response.data;
                                          var len=finalData[0].bgorder.bgMainNumberOfAmendment;

                                          var idVal= parseInt(id);
                                          console.log("length",len);
                                          console.log("idVal",idVal);



                            if (idVal==len){

                                          $scope.bgamendAmountval=finalData[0].bgorder.principalAmount;

                                          $scope.bgAmendExpiryDateval=finalData[0].bgorder.expiryDate;
                                          $scope.bgTermsAndConditions =finalData[0].bgorder.termsAndConditions;


                                            console.log("id last:",idVal,"length",len)
                                          }

                                          else
                                                                                   {

                                                                                  $scope.bgamendAmountval=finalData[0].bgorder.bgAmendData[idVal].bgAmendPrincipalAmount;

                                                                                  $scope.bgAmendExpiryDateval=finalData[0].bgorder.bgAmendData[idVal].bgExpiryDate;
                                                                                  $scope.bgTermsAndConditions =finalData[0].bgorder.bgAmendData[idVal].bgTermsAndConditions;
                                                                                     }


                                          });
                              }

//History method


    $scope.bgmyvar = false;

      $scope.bghistorycus=(amendId)=>{

      $scope.bgmyvar = true;

      const getObj = apiBaseURL + "/employee-bg-orders/"+amendId;

           $http.get(getObj).then(function(response){

                                             var finalData = response.data;
                                            var len=finalData[0].bgorder.bgMainNumberOfAmendment;

      if($scope.bgnumberofamendval!=null){
                                            var idVal= parseInt($scope.bgnumberofamendval);
                                            console.log("length",len);
                                            console.log("idVal",idVal);


                              if (idVal==len){

                                        $scope.bgamendAmountval=finalData[0].bgorder.principalAmount;

                                         $scope.bgAmendExpiryDateval=finalData[0].bgorder.expiryDate;
                                         $scope.bgTermsAndConditions =finalData[0].bgorder.termsAndConditions;
      console.log("finalData[0].bgorder if case",finalData[0],"gap",finalData[0].bgorder);

                                            }

                                            else
                                             {
                                             console.log("finalData[0].bgorder.bgAmendData[idVal-1].principalAmount",finalData[0],"gap",finalData[0].bgorder.bgAmendData[idVal]);
                                         $scope.bgamendAmountval=finalData[0].bgorder.bgAmendData[idVal].bgAmendPrincipalAmount;

                                         $scope.bgAmendExpiryDateval=finalData[0].bgorder.bgAmendData[idVal].bgExpiryDate;
                                         $scope.bgTermsAndConditions =finalData[0].bgorder.bgAmendData[idVal].bgTermsAndConditions;
                                            }
  }

                                            });

          }
//


//END
////////////////////scroll down controller on landing page starts//////////////////////
           $scope.gotoBottom= function() {
                $location.hash('bottom');
                $anchorScroll();
              };
////////////////////scroll down controller on landing page ends////////////////////////

                 }
                 else{

                 console.log("Inside else statement ----->");
                 $location.path("/customer");
                 }
            });
//////////////message controller////////////////////////////////////////////////////
            app.controller('messageCtrl', function ($uibModalInstance, message) {
                        const modalInstanceTwo = this;
                        modalInstanceTwo.message = message.data;
                        console.log("message inside messageCtrl  ",modalInstanceTwo.message);
                    });
//////////////message controller////////////////////////////////////////////////////
