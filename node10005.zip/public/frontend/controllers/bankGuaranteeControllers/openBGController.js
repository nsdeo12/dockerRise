         app.controller('openBGController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore) {
        console.log("inside openBg controller");
         if($cookieStore.get('employee')){
           const apiBaseURL = $rootScope.apiBaseURL;
                              $http.get(apiBaseURL + "bgRequestID").then(function(response){
                              $rootScope.newOpenID = response.data.bgRequestID;
                               console.log("bgRequestID in employee home page===>",response.data.bgRequestID);
                                          });

         console.log("inside openBg controller2");


//          $http.get(apiBaseURL + "lcRequestID").then(function(response){
//                                                          $rootScope.BGRequestID = response.data.lcRequestID;
//                                                          console.log($rootScope.BGRequestID);
//                                                          });

                            $scope.message = 'Open Bank Guarentees ';
                            $scope.node = $rootScope.thisNode;
                            $scope.username = $cookieStore.get('employee');
                            console.log("OPENING ID ===>",$rootScope.ID ," node is ",$scope.node," username is ",$scope.username);
//                            const LCRequestId = $rootScope.lcRequestID;
                                $scope.bgOpenForm = {};
                                $scope.formError = false;
                            $scope.logout = function(){
                            $cookieStore.remove('employee');
                            $location.path("/customer");
                                };


                            const BGReqNumb =  $rootScope.bgOpenID;
                            console.log("rootscope in BGopen",BGReqNumb,$rootScope.bgOpenID);
                            const getObj = apiBaseURL + "bg-req/" + BGReqNumb;

                            console.log("bg open object --->",getObj);
                            $http.get(getObj).then(function(response){
                             var modelData = response.data;
                             console.log("RESPONSE DATA ", modelData);
                             $rootScope.oldbgId = modelData.bgReqID;

                             var dt=new Date(modelData.dealDate).toLocaleDateString();
                             console.log("date",dt);
                             console.log("date1",modelData.dealDate);
                                                         console.log("modelData.ibanNumbera",modelData.ibanNumber);



                                        $scope.bgOpenForm.bgID= "BG-"+$rootScope.newOpenID;
                                        /* $scope.bgForm.bgissuedate = new Date();*/
                                        $scope.bgOpenForm.guaranteeReference=modelData.guaranteeReference;
                                        $scope.bgOpenForm.customerReference=modelData.customerReference;
                                        $scope.bgOpenForm.applicantCustomer=modelData.applicantCustomer;
                                        $scope.bgOpenForm.applicantCustomerAddress=modelData.applicantCustomerAddress;

                                        $scope.bgOpenForm.currency=modelData.currency;
                                        $scope.bgOpenForm.principalAmount=modelData.principalAmount;

                                        $scope.bgOpenForm.beneficiaryBankAddress=modelData.beneficiaryBankAddress;
                                        $scope.bgOpenForm.beneficiaryBank=modelData.beneficiaryBank;

                                        $scope.bgOpenForm.applicantBank=modelData.applicantBank;
                                        $scope.bgOpenForm.applicantBankAddress=modelData.applicantBankAddress;

                                        $scope.bgOpenForm.dealDate= modelData.dealDate;
                                        $scope.bgOpenForm.valueDate= modelData.valueDate;
                                        $scope.bgOpenForm.expiryDate= new Date(modelData.expiryDate).toLocaleDateString();
                                        $scope.bgOpenForm.maturityDate= new Date(modelData.maturityDate).toLocaleDateString();

                                        $scope.bgOpenForm.beneficiary=modelData.beneficiary;
                                        $scope.bgOpenForm.beneficiaryAddress=modelData.beneficiaryAddress;

                                        $scope.bgOpenForm.termsAndConditions=modelData.termsAndConditions;
                                        $scope.bgOpenForm.ibanNumber=modelData.ibanNumber;

                                        $scope.bgOpenForm.furtherIdentification=modelData.furtherIdentification;
                                        $scope.bgOpenForm.detailsOfGuarantee1=modelData.detailsOfGuarantee1;
                                        $scope.bgOpenForm.applicableRule=modelData.applicableRule;


                                        $scope.bgOpenForm.senderToReceiverInformation=modelData.senderToReceiverInformation;
                                        $scope.bgOpenForm.narrative=modelData.narrative;

            });


           $scope.Openbg = () => {

                            const openBG = {

                                bgID : $scope.bgOpenForm.bgID,
                                bgReqID : $rootScope.oldbgId,
                                guaranteeReference:$scope.bgOpenForm.guaranteeReference,
                                customerReference:$scope.bgOpenForm.customerReference,
                                applicantCustomer:$scope.bgOpenForm.applicantCustomer,
                                applicantCustomerAddress:$scope.bgOpenForm.applicantCustomerAddress,


                                currency:$scope.bgOpenForm.currency,

                                principalAmount:$scope.bgOpenForm.principalAmount,
                                beneficiaryBankAddress:$scope.bgOpenForm.beneficiaryBankAddress,
                                beneficiaryBank:$scope.bgOpenForm.beneficiaryBank,


                                applicantBank:$scope.bgOpenForm.applicantBank,
                                applicantBankAddress:$scope.bgOpenForm.applicantBankAddress,


                                dealDate:$scope.bgOpenForm.dealDate,
                                valueDate:$scope.bgOpenForm.valueDate,
                                expiryDate:$scope.bgOpenForm.expiryDate,
                                maturityDate:$scope.bgOpenForm.maturityDate,


                                beneficiary:$scope.bgOpenForm.beneficiary,
                                beneficiaryAddress:$scope.bgOpenForm.beneficiaryAddress,
                                termsAndConditions:$scope.bgOpenForm.termsAndConditions,
                                ibanNumber:$scope.bgOpenForm.ibanNumber,
                                furtherIdentification:$scope.bgOpenForm.furtherIdentification,
                                detailsOfGuarantee1:$scope.bgOpenForm.detailsOfGuarantee1,
                                senderToReceiverInformation:$scope.bgOpenForm.senderToReceiverInformation,
                                applicableRule:$scope.bgOpenForm.applicableRule,
                                narrative:$scope.bgOpenForm.narrative,

                         };

                        const openBGEndpoint =
                            apiBaseURL +"bg-open";

                       /*$http.post(openLCEndpoint, angular.toJson(openLoc)).then(
                            (result) => displayMessage(result),
                            (result) => displayMessage(result)
                        );*/
                        $http.post(openBGEndpoint, angular.toJson(openBG)).then(
                           function(result){
                            console.log("INSIDE SUCCESS FUNCTION",openBG);
                            $location.path("/employeeHome");
                            displayMessage(result);
                            }, 
                            function(result){
                            // failure callback
                            console.log("INSIDE ERROR FUNCTION");
                            displayMessage(result);
                                            }
                                //(result) => displayMessage(result),
                                //(result) => displayMessage(result)
                            );
                         console.log("BG opened and the object is  ",openBG);

                                }
                                $scope.cancel = () => {
                                      $location.path("/employeeHome");
                                }
                                displayMessage = (message) => {
                                console.log("message in display message--->",message);
                                        const modalInstanceTwo = $uibModal.open({
                                            templateUrl: 'messageContent.html',
                                            controller: 'messageCtrl',
                                            controllerAs: 'modalInstanceTwo',
                                            resolve: { message: () => message }
                                        });

                                        modalInstanceTwo.result.then(() => {}, () => {});
                                    };


                  			  }

                              else{
                              $location.path("/employeeLogin");
                              }

                          });

   //End
