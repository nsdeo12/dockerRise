app.controller('bgAmendApproveController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore) {
  if($cookieStore.get('employee')){
                    $scope.message = 'Approve Amended Letter of Credits ';
                    $scope.node = $rootScope.thisNode;
                     $scope.username = $cookieStore.get('employee');
                     console.log("AMENDING ID ===>",$rootScope.bgApproveAmendID,"  node is ",$scope.node," username is ",$scope.username);
                     //const LCAmendNumb = $rootScope.AmendID;


                        $scope.logout = function(){
                        $cookieStore.remove('employee');
                        $location.path("/customer");
                            };
                        $scope.bgAmendApproveForm = {};
                        $scope.formError = false;

                    const BGApproveAmendID = $rootScope.bgApproveAmendID;
                    const BGAmendReqNumb = $rootScope.AmendReqID;

                    const apiBaseURL = $rootScope.apiBaseURL;
                    //const getObj = apiBaseURL + "lc-orders";
                    const cusID1 = $cookieStore.get('employee');
                    const getObj = apiBaseURL + "employee-bg-orders/"+BGApproveAmendID;

                    $http.get(getObj).then(function(response){
                    var finalData = response.data;
                    console.log("corda data in bgAmendApproveController ", finalData[0]);
                    const numberOfAmendment=finalData[0].bgorder.bgMainNumberOfAmendment;
                     $scope.numberOfAmendment = numberOfAmendment;
console.log("Number of amendement  ",$scope.numberOfAmendment);
                    $scope.bgRequestID = finalData[0].bgorder.bgReqID;
                console.log("BG REQUEST ID   ", finalData[0].bgorder.bgReqID);
                    $scope.bgAmendApproveForm.bgAmendNo =  finalData[0].bgorder.bgID;
                    $scope.bgAmendApproveForm.bgAmendReqNo =  $scope.bgRequestID+"-00"+$scope.numberOfAmendment;

                $scope.bgAmendApproveForm.bgamendamount = finalData[0].bgorder.principalAmount;
                $scope.bgAmendApproveForm.bgamendtermsandconditions = finalData[0].bgorder.termsAndConditions;
                var pattern = /(\d{2})(\d{2})(\d{4})/;
                $scope.bgAmendApproveForm.bgamendexpirydate = new Date(finalData[0].bgorder.expiryDate.replace(pattern, '$1-$2-$3'));


                const length = finalData[0].bgorder.bgAmendData.length;
                      console.log("lenght",length, finalData[0].bgorder.bgAmendData);
                      $scope.bgAmendApproveForm.expiryDate = new Date((finalData[0].bgorder.bgAmendData[length-1].bgExpiryDate).replace(pattern, '$1-$2-$3'));
                      $scope.bgAmendApproveForm.principalAmount = finalData[0].bgorder.bgAmendData[length-1].bgAmendPrincipalAmount;
                      $scope.bgAmendApproveForm.termsAndConditions =  finalData[0].bgorder.bgAmendData[length-1].bgTermsAndConditions;
                      //$scope.bgAmendApproveForm.bgmainnumberofamendment =  finalData[0].bgorder.bgAmendData[length-1].bgSubNumberOfAmendment;

                      //New Changes:10-04-2017 : Begin
                       //var pattern = /(\d{2})(\d{2})(\d{4})/;
                        $scope.bgAmendApproveForm.bgID = finalData[0].bgorder.bgID;
                        $scope.bgAmendApproveForm.guaranteeReference = finalData[0].bgorder.guaranteeReference;
                        $scope.bgAmendApproveForm.customerReference = finalData[0].bgorder.customerReference;
                        $scope.bgAmendApproveForm.currency =  finalData[0].bgorder.currency;
                        //$scope.bgAmendApproveForm.principalAmount = finalData[0].bgorder.principalAmount;
                        $scope.bgAmendApproveForm.applicantCustomer = finalData[0].bgorder.applicantCustomer;
                        $scope.bgAmendApproveForm.applicantCustomerAddress = finalData[0].bgorder.applicantCustomerAddress;
                        $scope.bgAmendApproveForm.beneficiarybank =  finalData[0].bgorder.beneficiaryBank;
                        $scope.bgAmendApproveForm.beneficiarybankaddress =  finalData[0].bgorder.beneficiaryBankAddress;
                        $scope.bgAmendApproveForm.applicantBank = finalData[0].bgorder.applicantBank;
                        $scope.bgAmendApproveForm.applicantBankAddress = finalData[0].bgorder.applicantBankAddress;

                        $scope.bgAmendApproveForm.dealDate = new Date((finalData[0].bgorder.dealDate).replace(pattern, '$1-$2-$3'));

                        $scope.bgAmendApproveForm.valueDate = new Date((finalData[0].bgorder.valueDate).replace(pattern, '$1-$2-$3'));
                        //$scope.bgAmendApproveForm.expiryDate = new Date((finalData[0].bgorder.expiryDate).replace(pattern, '$1-$2-$3'));
                        $scope.bgAmendApproveForm.maturityDate =  new Date((finalData[0].bgorder.maturityDate).replace(pattern, '$1-$2-$3'));
                        //$scope.bgAmendForm.bgissuedate =  finalData[0].bgorder.maturityDate;
                        $scope.bgAmendApproveForm.beneficiary = finalData[0].bgorder.beneficiary;
                        $scope.bgAmendApproveForm.beneficiaryAddress = finalData[0].bgorder.beneficiaryAddress;
                        //$scope.bgAmendApproveForm.termsAndConditions = finalData[0].bgorder.termsAndConditions;
                        $scope.bgAmendApproveForm.bgmainnumberofamendment = finalData[0].bgorder.BGMainNumberOfAmendment;
                        $scope.bgAmendApproveForm.ibanNumber = finalData[0].bgorder.ibanNumber;
                        $scope.bgAmendApproveForm.details = finalData[0].bgorder.detailsOfGuarantee1;
                        $scope.bgAmendApproveForm.srInfo = finalData[0].bgorder.senderToReceiverInformation;
                        $scope.bgAmendApproveForm.applicableRule = finalData[0].bgorder.applicableRule;
                        $scope.bgAmendApproveForm.narrative = finalData[0].bgorder.narrative;
                         $scope.bgAmendApproveForm.furtherIdentification = finalData[0].bgorder.furtherIdentification;
//New Changes:10-04-2017 : END
                        });



                    $scope.amendApproveBG = () => {
                    const amendApproveBG = {
                                bgID : $scope.bgAmendApproveForm.bgID,
                               bgReqID : $scope.bgRequestID,
                               	guaranteeReference :  $scope.bgAmendApproveForm.guaranteeReference,
                               	customerReference : $scope.bgAmendApproveForm.customerReference,
                                 applicantCustomer : $scope.bgAmendApproveForm.applicantCustomer,
                                 applicantCustomerAddress : $scope.bgAmendApproveForm.applicantCustomerAddress,
                               	currency : $scope.bgAmendApproveForm.currency,
                               	principalAmount : $scope.bgAmendApproveForm.bgamendamount,
                                 beneficiaryBankAddress : $scope.bgAmendApproveForm.beneficiarybankaddress,
                               	beneficiaryBank : $scope.bgAmendApproveForm.beneficiarybank,
                               	applicantBank : $scope.bgAmendApproveForm.applicantBank,
                                 applicantBankAddress : $scope.bgAmendApproveForm.applicantBankAddress,
                               	dealDate : $scope.bgAmendApproveForm.dealDate,
                               	valueDate : $scope.bgAmendApproveForm.valueDate,
                               	expiryDate : new Date($scope.bgAmendApproveForm.bgamendexpirydate).toLocaleDateString(),
                               	maturityDate : $scope.bgAmendApproveForm.maturityDate,
                               	beneficiary : $scope.bgAmendApproveForm.beneficiary,
                               	beneficiaryAddress : $scope.bgAmendApproveForm.beneficiaryAddress,
                               	termsAndConditions : $scope.bgAmendApproveForm.bgamendtermsandconditions,
                               	bgMainNumberOfAmendment : $scope.numberOfAmendment,
                               	ibanNumber : $scope.bgAmendApproveForm.ibanNumber,
                               	furtherIdentification : $scope.bgAmendApproveForm.furtherIdentification,
                               	detailsOfGuarantee1 : $scope.bgAmendApproveForm.details,
                               	senderToReceiverInformation : $scope.bgAmendApproveForm.srInfo,
                               	applicableRule : $scope.bgAmendApproveForm.applicableRule,
                               	narrative : $scope.bgAmendApproveForm.narrative

      //status : "APPROVED"
                                };
                                    const approveBGEndpoint =
                                        apiBaseURL +"bg-amend-approve";

console.log("amendApprove BG object  ",amendApproveBG);
                                   $http.post(approveBGEndpoint, angular.toJson(amendApproveBG)).then(
                                   function(result){
                                    // success callback
                                    console.log("INSIDE SUCCESS FUNCTION");
                                    $location.path("/employeeHome");
                                    displayMessage(result);
                                    }, 
                                    function(result){
                                    // failure callback
                                    console.log("INSIDE ERROR FUNCTION");
                                    displayMessage(result);
                                                                         }
                                        //(result) => displayMessage(result),
                                        //(result) => displayMessage(result)
                                    );
                                    // console.log("LC approved and the object is  ",approveLoc);
                                     //console.log("message status" , $scope.messageStatus);
                                     //$location.path("/home");
                        }
                        $scope.cancel = () => {
                              $location.path("/employeeHome");
                        }
                        displayMessage = (message) => {
                        console.log("message in display message--->",message);
                        $rootScope.messageStatus = message.status;
                                const modalInstanceTwo = $uibModal.open({
                                    templateUrl: 'messageContent.html',
                                    controller: 'messageCtrl',
                                    controllerAs: 'modalInstanceTwo',
                                    resolve: { message: () => message }
                                });

                                modalInstanceTwo.result.then(() => {}, () => {});
                            };

                        function invalidFormInput() {
                            const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                    //            || !modalInstance.form.deliveryDate
                    //            || !modalInstance.form.city
                    //            || !modalInstance.form.country;
                    //
                    //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                    //
                    //        const invalidItemFields = modalInstance.items
                    //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                    //            .reduce((prev, curr) => prev && curr);

                            return invalidNonItemFields;
                        }
                        }
                                                else{
                                                $location.path("/customer");
                                                }

                  });
