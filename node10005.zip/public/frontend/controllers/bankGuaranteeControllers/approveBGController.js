 app.controller('approveBGController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore) {
  if($cookieStore.get('employee')){
                      const apiBaseURL = $rootScope.apiBaseURL;

                     $http.get(apiBaseURL + "bgRequestID").then(function(response){
                     $rootScope.bgRequestID = response.data.bgRequestID;
                      console.log("bgRequestID in employee home page===>",response.data.bgRequestID);
                                 });

                    $scope.message = 'Approve Bank Guarantee ';
                    $scope.node = $rootScope.thisNode;
                     $scope.username = $cookieStore.get('employee');
                     console.log("APPROVING ID ===>",$rootScope.bgApproveID,"  node is ",$scope.node," username is ",$scope.username);
//                     const LCReqNumb = $rootScope.bgApproveID;

                        $scope.logout = function(){
                        $cookieStore.remove('employee');
                        $location.path("/customer");
                            };
                        $scope.bgApproveForm = {};
                        $scope.formError = false;

                    $scope.BGApprovalId = $rootScope.bgApproveID;
                    //const getObj = apiBaseURL + "lc-orders";
                    const cusID1 = $cookieStore.get('employee');
                    const getObj = apiBaseURL + "employee-bg-orders/"+$scope.BGApprovalId;

                    $http.get(getObj).then(function(response){
                    var finalData = response.data;
                    var responseModel = finalData[0].bgorder;
                    console.log("RESPONSE DATA ", finalData);
                    console.log("RESPONSE DATA final", finalData[0].bgorder,finalData[0]);
                  //  $scope.lcRequestID = finalData[0].bgOrder.lcReqId;

//responseModel.bgID = "BG-"+$rootScope.bgRequestID;

$rootScope.modelToSend = responseModel;

console.log("responseModel.bgID", responseModel.bgID);
$scope.bgApproveForm.bgReqNo = $scope.BGApprovalId;
$scope.bgApproveForm.guaranteeReference = finalData[0].bgorder.guaranteeReference;
$scope.bgApproveForm.customerReference = finalData[0].bgorder.customerReference;
$scope.bgApproveForm.applicantCustomer = finalData[0].bgorder.applicantCustomer;
$scope.bgApproveForm.applicantCustomerAddress = finalData[0].bgorder.applicantCustomerAddress;
$scope.bgApproveForm.currency = finalData[0].bgorder.currency;
$scope.bgApproveForm.principalAmount = finalData[0].bgorder.principalAmount;
$scope.bgApproveForm.beneficiaryBankAddress = finalData[0].bgorder.beneficiaryBankAddress;
$scope.bgApproveForm.beneficiaryBank = finalData[0].bgorder.beneficiaryBank;
$scope.bgApproveForm.applicantBank = finalData[0].bgorder.applicantBank;
$scope.bgApproveForm.applicantBankAddress = finalData[0].bgorder.applicantBankAddress;
$scope.bgApproveForm.dealDate = finalData[0].bgorder.dealDate;
$scope.bgApproveForm.valueDate = finalData[0].bgorder.valueDate;
$scope.bgApproveForm.expiryDate = finalData[0].bgorder.expiryDate;
$scope.bgApproveForm.maturityDate = finalData[0].bgorder.maturityDate;
$scope.bgApproveForm.beneficiary = finalData[0].bgorder.beneficiary;
$scope.bgApproveForm.beneficiaryAddress = finalData[0].bgorder.beneficiaryAddress;
$scope.bgApproveForm.termsAndConditions = finalData[0].bgorder.termsAndConditions;
$scope.bgApproveForm.ibanNumber = finalData[0].bgorder.ibanNumber;
$scope.bgApproveForm.furtherIdentification = finalData[0].bgorder.furtherIdentification;
$scope.bgApproveForm.detailsOfGuarantee1 = finalData[0].bgorder.detailsOfGuarantee1;
$scope.bgApproveForm.senderToReceiverInformation = finalData[0].bgorder.senderToReceiverInformation;
$scope.bgApproveForm.applicableRule = finalData[0].bgorder.applicableRule;
$scope.bgApproveForm.narrative = finalData[0].bgorder.narrative;

                        });


                    $scope.approveBG = () => {

                   const approveBG = {
bgID:$scope.bgApproveForm.bgReqNo,
guaranteeReference:$scope.bgApproveForm.guaranteeReference,
customerReference:$scope.bgApproveForm.customerReference,
applicantCustomer:$scope.bgApproveForm.applicantCustomer,
applicantCustomerAddress:$scope.bgApproveForm.applicantCustomerAddress,
currency:$scope.bgApproveForm.currency,
principalAmount:$scope.bgApproveForm.principalAmount,
beneficiaryBankAddress:$scope.bgApproveForm.beneficiaryBankAddress,
beneficiaryBank:$scope.bgApproveForm.beneficiaryBank,
applicantBank:$scope.bgApproveForm.applicantBank,
applicantBankAddress:$scope.bgApproveForm.applicantBankAddress,
dealDate:$scope.bgApproveForm.dealDate,
valueDate:$scope.bgApproveForm.valueDate,
expiryDate:$scope.bgApproveForm.expiryDate,
maturityDate:$scope.bgApproveForm.maturityDate,
beneficiary:$scope.bgApproveForm.beneficiary,
beneficiaryAddress:$scope.bgApproveForm.beneficiaryAddress,
termsAndConditions:$scope.bgApproveForm.termsAndConditions,
ibanNumber:$scope.bgApproveForm.ibanNumber,
furtherIdentification:$scope.bgApproveForm.furtherIdentification,
detailsOfGuarantee1:$scope.bgApproveForm.detailsOfGuarantee1,
senderToReceiverInformation:$scope.bgApproveForm.senderToReceiverInformation,
applicableRule:$scope.bgApproveForm.applicableRule,
narrative:$scope.bgApproveForm.narrative,
                                                               };

                                    const approveLCEndpoint =
                                        apiBaseURL +"bg-approve";

                                   console.log("approve BG object  ",$rootScope.modelToSend);
                                   $http.post(approveLCEndpoint, angular.toJson($rootScope.modelToSend)).then(
                                   function(result){
                                    // success callback
                                    console.log("INSIDE SUCCESS FUNCTION");
                                    $location.path("/employeeHome");
                                    displayMessage(result);
                                    }, 
                                    function(result){
                                    // failure callback
                                    console.log("INSIDE ERROR FUNCTION");
                                    displayMessage(result);
                                                                         }
                                        //(result) => displayMessage(result),
                                        //(result) => displayMessage(result)
                                    );
                                    // console.log("LC approved and the object is  ",approveLoc);
                                     //console.log("message status" , $scope.messageStatus);
                                     //$location.path("/home");
                        }
                        $scope.cancel = () => {
                              $location.path("/employeeHome");
                        }
                        displayMessage = (message) => {
                        console.log("message in display message--->",message);
                        $rootScope.messageStatus = message.status;
                                const modalInstanceTwo = $uibModal.open({
                                    templateUrl: 'messageContent.html',
                                    controller: 'messageCtrl',
                                    controllerAs: 'modalInstanceTwo',
                                    resolve: { message: () => message }
                                });

                                modalInstanceTwo.result.then(() => {}, () => {});
                            };

                        function invalidFormInput() {
                            const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                    //            || !modalInstance.form.deliveryDate
                    //            || !modalInstance.form.city
                    //            || !modalInstance.form.country;
                    //
                    //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                    //
                    //        const invalidItemFields = modalInstance.items
                    //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                    //            .reduce((prev, curr) => prev && curr);

                            return invalidNonItemFields;
                        }
                        }
                                                else{
                                                $location.path("/customer");
                                                }

                  });
