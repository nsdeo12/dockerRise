  app.controller('bgAmendController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore,$filter) {
   if($cookieStore.get('customer')){
                     $scope.message = 'Amend Letter of Credits ';
                     $scope.node = $rootScope.thisNode;
                      $scope.username = $cookieStore.get('customer');
const apiBaseURL = $rootScope.apiBaseURL;
                      $http.get(apiBaseURL + "lcRequestID").then(function(response){
                                                                      $scope.BGRequestID = response.data.lcRequestID;
                                                                      console.log($scope.BGRequestID );
                                                                      });


                      console.log("AmendID ID ===>",$rootScope.BgAmendID,"  node is ",$scope.node," username is ",$scope.username);
                      const BGReqNumb = $rootScope.ID;

                        $scope.logout = function(){
                         $cookieStore.remove('customer');
                         $location.path("/customer");
                             };
                         $scope.bgAmendForm = {};
                         $scope.formError = false;


                    const BGAmendRequestId = $scope.BGRequestID ;
                     //const getObj = apiBaseURL + "lc-orders";
                     const cusID1 = $cookieStore.get('customer');
                     const getObj = apiBaseURL + "customer-bg-orders/"+cusID1;

                     $http.get(getObj).then(function(response){
                     var finalData = response.data;
                     console.log("RESPONSE DATA ", finalData);
                  var finaldatalength= finalData.length;
                  console.log("finaldatalength DATA ", finaldatalength);
                  for (i=0; i<finaldatalength; i++){

                    const selectlcid= $rootScope.BgAmendID;
                    console.log("selectlcid----",selectlcid);
                    const amendid =finalData[i].bgorder.bgID;
                     console.log("amendid----",amendid);
                  if (selectlcid == amendid){
                    const index = 0;
                    $rootScope.index = i;
                    // console.log("RESPONSE DATA in amend ----->", finalData.lcorder.finalData[i]);
                     $scope.bgRequestID = finalData[i].bgorder.bgReqID;

                       $scope.bgAmendForm.bgamendId = finalData[i].bgorder.bgID;
                            const BGRequestId = $rootScope.bgRequestID;
                            const numberOfAmendment=finalData[i].bgorder.bgMainNumberOfAmendment+1;
                            $scope.numberOfAmendment = numberOfAmendment;
                        $scope.bgamendrequestID = finalData[i].bgorder.bgReqID+"-00"+numberOfAmendment;
                        console.log("BG AMEND ID====>  "+$scope.bgamendrequestID);
                        //$scope.bgAmendForm.bgamendreq = bgamendrequestID;

                        $scope.bgAmendForm.bgAmendNo =  finalData[i].bgorder.bgID;
                        $scope.bgAmendForm.bgAmendReqNo =  $scope.bgamendrequestID;

                        var expdt = finalData[i].bgorder.expiryDate;
                        var pattern = /(\d{2})(\d{2})(\d{4})/;
                        $scope.bgAmendForm.bgamendexpirydate = new Date(expdt.replace(pattern, '$1-$2-$3'));
                        $scope.bgAmendForm.bgamendamount =  finalData[i].bgorder.principalAmount;
                        $scope.bgAmendForm.bgamendtermsandconditions =  finalData[i].bgorder.termsAndConditions;

                        $scope.bgAmendForm.bgID = finalData[i].bgorder.bgID;
                        $scope.bgAmendForm.guaranteeReference = finalData[i].bgorder.guaranteeReference;
                        $scope.bgAmendForm.customerReference = finalData[i].bgorder.customerReference;
                        $scope.bgAmendForm.currency =  finalData[i].bgorder.currency;
                        $scope.bgAmendForm.principalAmount = finalData[i].bgorder.principalAmount;
                        $scope.bgAmendForm.applicantCustomer = finalData[i].bgorder.applicantCustomer;
                        $scope.bgAmendForm.applicantCustomerAddress = finalData[i].bgorder.applicantCustomerAddress;
                        $scope.bgAmendForm.beneficiarybank =  finalData[i].bgorder.beneficiaryBank;
                        $scope.bgAmendForm.beneficiarybankaddress =  finalData[i].bgorder.beneficiaryBankAddress;
                        $scope.bgAmendForm.applicantBank = finalData[i].bgorder.applicantBank;
                        $scope.bgAmendForm.applicantBankAddress = finalData[i].bgorder.applicantBankAddress;

                        $scope.bgAmendForm.dealDate = new Date((finalData[i].bgorder.dealDate).replace(pattern, '$1-$2-$3'));

                        $scope.bgAmendForm.valueDate = new Date((finalData[i].bgorder.valueDate).replace(pattern, '$1-$2-$3'));
                        $scope.bgAmendForm.expiryDate = new Date((finalData[i].bgorder.expiryDate).replace(pattern, '$1-$2-$3'));
                        $scope.bgAmendForm.maturityDate =  new Date((finalData[i].bgorder.maturityDate).replace(pattern, '$1-$2-$3'));
                        //$scope.bgAmendForm.bgissuedate =  finalData[i].bgorder.maturityDate;
                        $scope.bgAmendForm.beneficiary = finalData[i].bgorder.beneficiary;
                        $scope.bgAmendForm.beneficiaryAddress = finalData[i].bgorder.beneficiaryAddress;
                        $scope.bgAmendForm.termsAndConditions = finalData[i].bgorder.termsAndConditions;
                        $scope.bgAmendForm.bgmainnumberofamendment = finalData[i].bgorder.BGMainNumberOfAmendment;
                        $scope.bgAmendForm.ibanNumber = finalData[i].bgorder.ibanNumber;
                        $scope.bgAmendForm.details = finalData[i].bgorder.detailsOfGuarantee1;
                        $scope.bgAmendForm.srInfo = finalData[i].bgorder.senderToReceiverInformation;
                        $scope.bgAmendForm.applicableRule = finalData[i].bgorder.applicableRule;
                        $scope.bgAmendForm.narrative = finalData[i].bgorder.narrative;
                         $scope.bgAmendForm.furtherIdentification = finalData[i].bgorder.furtherIdentification;
                //New Changes:10-04-2017 :END

                        $scope.bgAmendAmountcheck = () =>  {
         console.log("LC AMOUNT",$scope.bgAmendForm.bgamendamount);
                        var value = $scope.bgAmendForm.bgamendamount;
                       
                        var Amtval = value.split(/^([-+]?[0-9]*\.?[0-9]+)([abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ])$/);
                        console.log("AMT VAL  ",Amtval);

                        if(Amtval[2].toLowerCase()=='m'|| Amtval[2].toLowerCase()=='h'|| Amtval[2].toLowerCase()=='t'){

                        if(Amtval[2].toLowerCase()== "m"){
                        $scope.bgAmendForm.bgamendamount = Amtval[1]*1000000;
                        }
                        else if(Amtval[2].toLowerCase()== "h")
                        {
                        $scope.bgAmendForm.bgamendamount = Amtval[1]*100;
                        }
                        else if(Amtval[2].toLowerCase()== "t")
                        {
                        $scope.bgAmendForm.bgamendamount = Amtval[1]*1000;
                        }
                        else {
                        $scope.bgAmendForm.bgamendamount = $scope.bgAmendForm.bgamendamount;
                        }
                        }
                        else{
                        console.log("inside check else");
                        $scope.bgAmendForm.bgamendamount = "";

                        }
    }
                        //end here

                       } } });
                         console.log("Before scope");

                $scope.changebgamendfields= () => {

                //bg amount chnge logic

//end

                   $http.get(getObj).then(function(response){
                   var finalData = response.data;
                   console.log("RESPONSE DATA inside ", finalData);
                   console.log("$rootScope.index value", $rootScope.index);
                   console.log("RESPONSE DATA in amend insdi ----->", finalData[$rootScope.index].bgorder,finalData[$rootScope.index]);


                   $scope.oldvaluefromcorda = {
                                expirydate : finalData[$rootScope.index].bgorder.expiryDate,
                                bgamount : finalData[$rootScope.index].bgorder.principalAmount,
                                termsandconditions : finalData[$rootScope.index].bgorder.termsAndConditions,
                                   }
console.log("oldvaluefromcorda-inside--->",$scope.oldvaluefromcorda);

                 $scope.fieldvaluefromUI = {

                           bgAmendAmountfieldlevel: $scope.bgAmendForm.bgamendamount,
                           bgAmendTermsAndConditionsfieldlevel : $scope.bgAmendForm.bgamendtermsandconditions,
                           bgAmendExpiryDatefieldlevel : new Date($scope.bgAmendForm.bgamendexpirydate).toLocaleDateString(),

                        }
                    console.log("fieldvaluefromUI---->",$scope.fieldvaluefromUI);
$scope.bgcheck= () => {


if(($scope.oldvaluefromcorda.expirydate == $scope.fieldvaluefromUI.bgAmendExpiryDatefieldlevel) && ($scope.oldvaluefromcorda.bgamount==$scope.fieldvaluefromUI.bgAmendAmountfieldlevel) && ($scope.oldvaluefromcorda.termsandconditions == $scope.fieldvaluefromUI.bgAmendTermsAndConditionsfieldlevel)){
console.log("inside if amend");

return false;
}
else {
console.log("inside else amend");
return true;
}

}


         });
         }






                     $scope.amendBG = () => {

                         const amendBG = {
                             bgAmendId : $scope.bgAmendForm.bgID,
                             bgAmendReqId: $scope.bgamendrequestID,
                             bgAmendPrincipalAmount:$scope.bgAmendForm.bgamendamount,
                             bgTermsAndConditions: $scope.bgAmendForm.bgamendtermsandconditions,
                             bgExpiryDate: new Date($scope.bgAmendForm.bgamendexpirydate).toLocaleDateString(),
                             bgSubNumberOfAmendment: $scope.numberOfAmendment,
                             bgstatus : "AMEND REQUESTED"
             };

                                 //if($scope.bgAmendForm.amendbeneficiarybank == null){
                                                                      //alert("Advising Bank Ref Cannot Be Empty");
                                                                  //}
                                 //else{
                                 console.log("amendbg value---",amendBG);
                                     const amendBGEndpoint = apiBaseURL +"bg-amend-req";
                            //console.log("approve LOC object  ",approveLOC);
                                    $http.post(amendBGEndpoint, angular.toJson(amendBG)).then(
                                    function(result){
                                     // success callback
                                     console.log("INSIDE SUCCESS FUNCTION");
                                     $location.path("/customerHome");
                                     displayMessage(result);
                                     },
                                     function(result){
                                     // failure callback
                                     console.log("INSIDE ERROR FUNCTION");
                                     displayMessage(result);
                                        }
                                     );
                                 //}
                         }
                         $scope.cancel = () => {
                               $location.path("/customerHome");
                         }
                         displayMessage = (message) => {
                         console.log("message in display message--->",message);
                         $rootScope.messageStatus = message.status;
                                 const modalInstanceTwo = $uibModal.open({
                                     templateUrl: 'messageContent.html',
                                     controller: 'messageCtrl',
                                     controllerAs: 'modalInstanceTwo',
                                     resolve: { message: () => message }
                                 });
                                 modalInstanceTwo.result.then(() => {}, () => {});
                             };
                         function invalidFormInput() {
                        //     const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                     //            || !modalInstance.form.deliveryDate
                     //            || !modalInstance.form.city
                     //            || !modalInstance.form.country;
                     //
                     //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                     //
                     //        const invalidItemFields = modalInstance.items
                     //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                     //            .reduce((prev, curr) => prev && curr);

                        //     return invalidNonItemFields;
                         }
                        }
                                                 else{
                                                 $location.path("/customer");
                                                 }

                   });


