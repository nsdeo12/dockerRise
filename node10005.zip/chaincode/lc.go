package main

import (
	"errors"
	"fmt"
	//"strconv"
	"encoding/json"
	"github.com/hyperledger/fabric/core/chaincode/shim"
)

var LCID = "LCID"

var logger = shim.NewLogger("mylogger")

type SimpleChaincode struct {
}

type LetterOfCredit struct{
LcId           						string        `json:"lcId"`
LcReqId								string        `json:"lcReqId"`
ApplicantCustomer					string        `json:"applicantCustomer"`
ApplicantAddress					string        `json:"applicantAddress"`
LcExpiryDate						string        `json:"lcExpiryDate"`
ModeOfShipment						string        `json:"modeOfShipment"`
BeneficiaryId						string        `json:"beneficiaryId"`
BeneficiaryAddress					string        `json:"beneficiaryAddress"`
LcType								string        `json:"lcType"`
LcCurrency							string        `json:"lcCurrency"`
LcAmount							int        	  `json:"lcAmount"`
LcAmountTemp						int        	  `json:"lcAmountTemp"`
LcIssueDate							string        `json:"lcIssueDate"`
LcExpiryPlace						string        `json:"lcExpiryPlace"`
LatestShipmentDate					string        `json:"latestShipmentDate"`
LiabilityReversalDate				string        `json:"liabilityReversalDate"`
AdvisingBankID						string		  `json:"advisingBankID"`
ApplicantBank						string        `json:"applicantBank"`
ApplicantBankAddress				string        `json:"applicantBankAddress"`
AdvisingBankAddress					string        `json:"advisingBankAddress"`
FormofDocumentaryCredit				string        `json:"formofDocumentaryCredit"`
DocumentaryCreditNumber				string        `json:"documentaryCreditNumber"`
AvailableWithBy						string        `json:"availableWithBy"`
ForTransportationTo					string        `json:"forTransportationTo"`
DescriptionOfGoodsAndOrServices		string        `json:"descriptionOfGoodsAndOrServices"`
AdditionalConditions				string        `json:"additionalConditions"`
PeriodForPresentation				string        `json:"periodForPresentation"`
AdvisingThroughBank					string        `json:"advisingThroughBank"`
Transshipment						string        `json:"transshipment"`
PortofLoading						string        `json:"portofLoading"`
MaximumCreditAmount					string        `json:"maximumCreditAmount"`
DraftsAt							string        `json:"draftsAt"`
PartialShipments					string        `json:"partialShipments"`
SenderToReceiverInformation			string        `json:"senderToReceiverInformation"`
Charges								string        `json:"charges"`
ConfirmationInstructions			string        `json:"confirmationInstructions"`
SequenceOfTotal						string        `json:"sequenceOfTotal"`
DocumentsRequired					string        `json:"documentsRequired"`
IbanNumber							string        `json:"ibanNumber"`
IncoTerms							string        `json:"incoTerms"`
DraftsAtSight						string        `json:"draftsAtSight"`
DraftsAtUsance						string        `json:"draftsAtUsance"`
ShipmentPeriodSight					int        	  `json:"shipmentPeriodSight"`
ShipmentPeriodUsance				int           `json:"shipmentPeriodUsance"`
PercentageSight						int           `json:"percentageSight"`
PercentageUsance					int           `json:"percentageUsance"`
LcAmountSight						int           `json:"lcAmountSight"`
LcAmountUsance						int           `json:"lcAmountUsance"`
Status								string		  `json:"status"`
}

func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {

var err error
	var empty []string
	jsonAsBytes, _ := json.Marshal(empty)
	err = stub.PutState(LCID, jsonAsBytes)
	
	if err != nil {
		return nil, err
	}

	return nil, nil
	
}

func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {
	
	if function == "OpenLetterOfCredit" {
		// creates an entity from its state
		return t.OpenLetterOfCredit(stub, args)
	}
	if function == "UpdateStatus" {
		// updates an entity from its state
		return t.UpdateStatus(stub, args)
	}
	
	return nil, nil
}

func (t *SimpleChaincode) Query(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {
	if function == "GetLcById" {
		// creates an entity from its state
		return t.GetLcById(stub, args)
	}
	if function == "GetAllLC" {
		// creates an entity from its state
		return t.GetAllLC(stub, args)
	}
			
	return nil, nil
}

func (t *SimpleChaincode) OpenLetterOfCredit(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering OpenLetterOfCredit")

	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for letter of credit creation")
	}

	var lcId = args[0]		
	var lcInput = args[1]
		
	//storing the Lc IDs
	
	LCIDAsBytes, err := stub.GetState(LCID)
	if err != nil {
		return nil, errors.New("Failed to get Student IDs")
	}
	
	var LCIDs []string
	json.Unmarshal(LCIDAsBytes, &LCIDs)	
	fmt.Println("LCIDs  ",LCIDs)
	
	//store and append the index to LCIDs
	
	LCIDs = append(LCIDs, args[0])									
	fmt.Println("LCIDs array: ", LCIDs)
	
	LCIdArrayAsBytes, _ := json.Marshal(LCIDs)
	err = stub.PutState(LCID, LCIdArrayAsBytes)	
	
	//END

	err = stub.PutState(lcId, []byte(lcInput))
	if err != nil {
		logger.Error("Could not save letter of credit to ledger", err)
		return nil, err
	}

	var customEvent = "{eventType: 'Letter of credit', description:" + lcId + "' Successfully created'}"
	err = stub.SetEvent("evtSender", []byte(customEvent))
	if err != nil {
		return nil, err
	}
	logger.Info("Successfully requested a Letter of credit")
	
	return nil, nil

}

func (t *SimpleChaincode) GetLcById(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetLcById")

	if len(args) < 1 {
		logger.Error("Invalid number of arguments")
		return nil, errors.New("Missing LC ID")
	}

	var lcId = args[0]
	bytes, err := stub.GetState(lcId)
	if err != nil {
		logger.Error("Could not fetch letter of credit with id "+lcId+" from ledger", err)
		return nil, err
	}
	return bytes, nil
}

func (t *SimpleChaincode) GetAllLC(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetAllLC")
	
	var jsonRespAll string		
	var data []byte
	var IDs []string	
	var LcArrayAsBytes []byte
	
	IDAsBytes, err := stub.GetState(LCID)
	if err != nil {
		//return fail, errors.New("Failed to get math index")
	}	
	json.Unmarshal(IDAsBytes, &IDs)
	fmt.Println("IDAsBytes :",IDs)
	
	for i := range(IDs){
       	fmt.Println("IDs :",IDs[i])
		var ID = IDs[i]
	   LcArrayAsBytes, err = stub.GetState(ID)						
		if err != nil {
		fmt.Println("error in fetching record")
			//return fail, errors.New("Failed to get ")
		}
				
		res := LetterOfCredit{}
		json.Unmarshal(LcArrayAsBytes, &res)										
		fmt.Println("res data:",res)
		s1, _ := json.Marshal(res)
	
	
	jsonRespAll = jsonRespAll+string(s1)
	fmt.Println("jsonRespAll   "+jsonRespAll)
		
		data = []byte(jsonRespAll)		
       
    }	
		return data, nil
	
}

func (t *SimpleChaincode) UpdateStatus(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering UpdateStatus")
	if len(args) < 2 {
		logger.Error("Invalid number of arguments")
		return nil, errors.New("Missing LC ID")
	}

	var lcid = args[0]
	var status = args[1]
	bytes, err := stub.GetState(lcid)
	if err != nil {
		logger.Error("Could not fetch letter of credit with id "+lcid+" from ledger", err)
		return nil, err
	}
	loc := LetterOfCredit{}
	json.Unmarshal(bytes, &loc)										
	fmt.Println("loc data:",loc)
	loc.Status = status
	fmt.Println("loc data after status change:",loc)
	s2, _ := json.Marshal(loc)
		
	err = stub.PutState(lcid, s2)
	if err != nil {
		logger.Error("Could not save letter of credit to ledger", err)
		return nil, err
	}
	
	return nil, nil
}

/*
func (t *SimpleChaincode) UpdateLetterOfCredit(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering UpdateLetterOfCredit")

	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for loan application update")
	}

	var loanApplicationId = args[0]
	var status = args[1]

	laBytes, err := stub.GetState(loanApplicationId)
	if err != nil {
		logger.Error("Could not fetch loan application from ledger", err)
		return nil, err
	}
	var loanApplication LoanApplication
	err = json.Unmarshal(laBytes, &loanApplication)
	loanApplication.Status = status

	laBytes, err = json.Marshal(&loanApplication)
	if err != nil {
		logger.Error("Could not marshal loan application post update", err)
		return nil, err
	}

	err = stub.PutState(loanApplicationId, laBytes)
	if err != nil {
		logger.Error("Could not save loan application post update", err)
		return nil, err
	}

	var customEvent = "{eventType: 'loanApplicationUpdate', description:" + loanApplicationId + "' Successfully updated status'}"
	err = stub.SetEvent("evtSender", []byte(customEvent))
	if err != nil {
		return nil, err
	}
	logger.Info("Successfully updated loan application")
	return nil, nil

}*/

func main() {
	err := shim.Start(new(SimpleChaincode))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}